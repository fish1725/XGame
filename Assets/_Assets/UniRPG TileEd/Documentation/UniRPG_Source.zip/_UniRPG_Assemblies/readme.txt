 -== UniRPG ==-
 by Leslie Young
 www.plyoung.com
 -============-
 
Some notes on how to compile the UniRPG Tile Ed. DLLs
 
 -============-

 UniRPG Tile Ed. is compiled into two DLLs. The one is for the editor part and the other for the runtime.
 
  - UniRPGEditor.dll should end up in an Editor folder, like \Assets\UniRPG TileEd\Editor\Scripts\ so that it is not included when you build the game, which would give errors.
  - UniRPGRuntime.dll can be anywhere, except Editor folders, for example at, \Assets\UniRPG TileEd\Scripts\
 
 -============-

 The included project files are for Visual Studio 2010.
 Make sure that the Unity DLLs are linked under references.
 
 - For UniRPGEditor you need both the UnityEditor and UnityEngine DLLs, they can be found at .....\Unity3\Editor\Data\Managed
 It also needs a reference to UniRPGRuntime.
 
 - The UniRPGRuntime project only needs the UnityEngine DLL.
 
 - You must change the two project's properties, "conditional compilation symbols" from Unity_3 to Unity_4 if you are compiling against the Unity 4 DLLs
 
 -============-
 
 To get debug info in Unity you need to generate .mdb files in the same folder the UniRPGEditor and UniRPGRuntime DLLs will end up (in Asset folder).
 This process can be automated and you can even take it so far as to have the dll and mdb files placed directly in your Asset foler each time you build the solution.
 
 You need to edit the two project files to fix the paths to have the mdb files generated.
 Right click on a project and select properties and then select the "build events" tab.
 Click on the "edit post-build" button and make changes as needed...
 
 UniRPGEditor's Post Build looks something like this ...
 
echo f | xcopy "$(TargetPath)" "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\" /Y 
echo f | xcopy "$(TargetDir)$(TargetName).pdb" "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\" /Y 
"C:\apps\Unity3\Editor\Data\Mono\lib\mono\2.0\pdb2mdb.exe" "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\$(TargetFileName)" 
echo f | xcopy "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\$(TargetFileName)" "D:\dev-games\unity\UniRPG\Assets\UniRPG TileEd\Editor\Scripts\" /Y 
echo f | xcopy "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\$(TargetFileName).mdb" "D:\dev-games\unity\UniRPG\Assets\UniRPG TileEd\Editor\Scripts\" /Y 
 
 UniRPGRuntime's Post Build looks something like this ...
 
echo f | xcopy "$(TargetPath)" "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\" /Y 
echo f | xcopy "$(TargetDir)$(TargetName).pdb" "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\" /Y 
"C:\apps\Unity3\Editor\Data\Mono\lib\mono\2.0\pdb2mdb.exe" "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\$(TargetFileName)" 
echo f | xcopy "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\$(TargetFileName)" "D:\dev-games\unity\UniRPG\Assets\UniRPG TileEd\Scripts\" /Y 
echo f | xcopy "D:\dev-games\unity\UniRPG\_UniRPG_Assemblies\bin\$(TargetFileName).mdb" "D:\dev-games\unity\UniRPG\Assets\UniRPG TileEd\Scripts\" /Y 

Change the paths as needed and keep in mind that you may only make the changes in the window that pops up after clicking the "edit post-build" button. It will not work if you make changes in the "post-build event command line textfield.

-============-
     end



