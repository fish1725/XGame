﻿// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class PlopInspectorBase : InspectorBase<Plop>
	{

		//public enum HeightSnapMode: int { None, Grid, Tiles }
		//private static HeightSnapMode heightSnapMode = HeightSnapMode.Grid;
		
		private Vector3 cursorPos = Vector3.zero;

		// ================================================================================================================
		#region Inspector

		public void OnEnable()
		{
			if (Target.map == null)
			{
				// find a default map to sit on
				Object obj = GameObject.FindObjectOfType(typeof(Map));
				if (obj != null) Target.map = (obj as Map);
			}
		}

		public void OnDisable(){}

		public void OnDestroy(){}

		public override void OnInspectorGUI()
		{
			UniRPGEditorBase.CheckGUISkin();
			EditorGUILayout.Space();
		}

		#endregion
		// ================================================================================================================
	}
}
