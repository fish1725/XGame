// ====================================================================================================================
// PLY Common Classes
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

namespace PLYCommon
{
	public class PLYEditorUtil
	{
		// ================================================================================================================
		#region gui styling

		// many of these are changed in CheckGUISkin from the defaults set here when light skin is used

		public static Color LineColor = new Color(1f, 1f, 1f, 0.1f); // default seperator like line
		public static Color LineDarkColor = new Color(0f, 0f, 0f, 0.2f);
		public static Color DefaultToggleButtonOnColor = new Color(0.0f, 0.5f, 1.0f, 1f);
		public static Color IconToggleButtonOffColor = new Color(0f, 0f, 0f, 0f);

		public static GUIStyle BoxStyle=null;
		public static GUIStyle FoldBoxStyle;
		public static GUIStyle FoldBoxHeadStyle;
		
		public static GUIStyle WarningLabelStyle;	// yellow text (in dark theme, else red)
		public static GUIStyle BoldLabelStyle;		// bold label

		public static GUIStyle MiniButtonLeftNoMarginStyle;
		public static GUIStyle MiniButtonMidNoMarginStyle;
		public static GUIStyle MiniButtonRightNoMarginStyle;

		private static string plyEditorPath = null;		// not used in UniRPG - "Assets/UniRPG/Editor";
		private static string[] plySkinPaths = null;	// not used in UniRPG - { "Skin/UniRPGSkinLight.guiskin", "Skin/UniRPGSkinDark.guiskin" };
		private static GUISkin plySkin = null;

		public static void CheckGUISkin()
		{
			// use BoxStyle to see if styles have been inited
			if (BoxStyle != null) return;

			// ----------------------------------------------------------------------------------------------------
			// init some styles that don't need skin file to define
			GUISkin inspectorSkin = EditorGUIUtility.GetBuiltinSkin(EditorSkin.Inspector);

			if (!EditorGUIUtility.isProSkin)
			{	// make changes to styles for light skin
				LineColor = new Color(0f, 0f, 0f, 0.25f);
			}

			BoxStyle = new GUIStyle(inspectorSkin.box);
			BoxStyle.name = "BoxStyle";

			FoldBoxStyle = new GUIStyle(inspectorSkin.box);
			FoldBoxStyle.name = "FoldBoxStyle";
			FoldBoxStyle.padding = new RectOffset(2, 0, 0, 0);

			FoldBoxHeadStyle = new GUIStyle(EditorStyles.boldLabel);
			FoldBoxHeadStyle.name = "FoldBoxHeadStyle";
			FoldBoxHeadStyle.padding = new RectOffset(0, 0, 0, 0);
			FoldBoxHeadStyle.margin = new RectOffset(2, 0, 2, 3);

			WarningLabelStyle = new GUIStyle(EditorStyles.miniLabel);
			WarningLabelStyle.name = "WarningLabelStyle";
			WarningLabelStyle.normal.textColor = (EditorGUIUtility.isProSkin ? Color.yellow : Color.red);

			BoldLabelStyle = new GUIStyle(EditorStyles.boldLabel);
			BoldLabelStyle.name = "BoldLabelStyle";
			BoldLabelStyle.padding = new RectOffset(0,0,0,0);
			BoldLabelStyle.margin = new RectOffset(3, 3, 0, 3);

			MiniButtonLeftNoMarginStyle = new GUIStyle(EditorStyles.miniButtonLeft);
			MiniButtonMidNoMarginStyle = new GUIStyle(EditorStyles.miniButtonMid);
			MiniButtonRightNoMarginStyle = new GUIStyle(EditorStyles.miniButtonRight);
			MiniButtonLeftNoMarginStyle.name = "MiniButtonLeftNoMarginStyle";
			MiniButtonMidNoMarginStyle.name = "MiniButtonMidNoMarginStyle";
			MiniButtonRightNoMarginStyle.name = "MiniButtonRightNoMarginStyle";
			MiniButtonLeftNoMarginStyle.margin = MiniButtonMidNoMarginStyle.margin = MiniButtonRightNoMarginStyle.margin = new RectOffset(0, 0, 0, 0);

			// ----------------------------------------------------------------------------------------------------
			// find and load skin
			if (plyEditorPath != null)
			{
				plySkin = LoadEditorResource<GUISkin>(plySkinPaths[EditorGUIUtility.isProSkin ? 1 : 0]) as GUISkin;
			}

		}

		#endregion
		// ================================================================================================================
		#region resource loading

		public static Object LoadEditorResource<T>(string resourcePath)
		{
			string editorPath = plyEditorPath;
			string projectPath = Application.dataPath;
			if (projectPath.EndsWith("/Assets")) projectPath = projectPath.Remove(projectPath.Length - ("Assets".Length));

			// check if resource file is where expected, else try and find it before giving up on it
			if (!File.Exists(projectPath + editorPath + "/" + resourcePath))
			{
				// file not found, search for location of the file
				DirectoryInfo dirNfo = new DirectoryInfo(Application.dataPath);

				Queue<DirectoryInfo> dirQueue = new Queue<DirectoryInfo>();
				dirQueue.Enqueue(dirNfo);

				bool found = false;
				while (dirQueue.Count > 0)
				{
					DirectoryInfo dir = dirQueue.Dequeue();
					if (File.Exists(dir.FullName + "/" + resourcePath))
					{
						string path = dir.FullName.Replace('\\', '/');
						found = true;
						path = path.Replace(projectPath, "");
						if (path.StartsWith("/")) path = path.Remove(0, 1);
						editorPath = path;
						break;
					}
					DirectoryInfo[] dirs = dir.GetDirectories();
					for (int i = 0; i < dirs.Length; i++) dirQueue.Enqueue(dirs[i]);
				}

				if (!found)
				{
					Debug.LogError(string.Format("Could not locate the resource [{0}]", resourcePath));
					return null;
				}
			}

			// load resource
			return AssetDatabase.LoadAssetAtPath(editorPath + "/" + resourcePath, typeof(T));
		}

		internal static Stream GetResourceStream(string fullResourceName, Assembly assembly)
		{
			if (assembly == null) assembly = Assembly.GetExecutingAssembly();
			return assembly.GetManifestResourceStream(fullResourceName);
		}

		internal static Stream GetResourceStream(string fullResourceName)
		{
			return GetResourceStream(fullResourceName, null);
		}

		internal static byte[] GetByteResource(string fullResourceName, Assembly assembly)
		{
			byte[] buffer;
			Stream byteStream = GetResourceStream(fullResourceName, assembly);
			if (byteStream == null) return new byte[0];
			buffer = new byte[byteStream.Length];
			byteStream.Read(buffer, 0, (int)byteStream.Length);
			byteStream.Close();
			return buffer;
		}

		internal static byte[] GetByteResource(string fullResourceName)
		{
			return GetByteResource(fullResourceName, null);
		}

		internal static Texture2D GetTextureResource(string fullResourceName, Assembly assembly)
		{
			Texture2D texture;
			texture = new Texture2D(1, 1);
			texture.LoadImage(GetByteResource(fullResourceName, assembly));
			return texture;
		}

		internal static Texture2D GetTextureResource(string fullResourceName)
		{
			return GetTextureResource(fullResourceName, typeof(PLYEditorUtil).Assembly);
		}

		#endregion
		// ================================================================================================================
		#region misc

		public static Texture2D GetAssetPreview(Object ob)
		{
			#if UNITY_3
			return EditorUtility.GetAssetPreview(ob);
			#else
			return AssetPreview.GetAssetPreview(ob);
			#endif
		}

		public static void HideRendererWireframe(GameObject go, bool hide)
		{
			EditorUtility.SetSelectedWireframeHidden(go.renderer, hide);
			for (int i = 0; i < go.transform.childCount; i++)
			{
				PLYEditorUtil.HideRendererWireframe(go.transform.GetChild(i).gameObject, hide);
			}
		}

		public static void FocusSceneView()
		{
			// focus the scene view
			if (SceneView.sceneViews.Count > 0) (SceneView.sceneViews[0] as SceneView).Focus();
		}

		#endregion
		// ================================================================================================================
		#region Custom GUI elements

		public static void IntVector2Field(string head, string label1, string label2, ref int val1, ref int val2)
		{
			GUILayout.Label(head, EditorStyles.label);
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.Space();
				GUILayout.Label(label1, EditorStyles.label);
				val1 = EditorGUILayout.IntField(val1);
				GUILayout.Label(label2, EditorStyles.label);
				val2 = EditorGUILayout.IntField(val2);
			}
			EditorGUILayout.EndHorizontal();
			EditorGUILayout.Space();
		}

		public static bool BeginVerticalFold(string label, bool expanded, params GUILayoutOption[] options)
		{
			FoldBoxStyle.padding.bottom = (expanded ? 7 : 0);
			EditorGUILayout.BeginVertical(FoldBoxStyle, options);
			if (GUILayout.Button(label, FoldBoxHeadStyle, options)) expanded = !expanded;
			return expanded;
		}

		public static void EndVerticalFold()
		{
			EditorGUILayout.EndVertical();
		}

		public static void BeginBox(string label, params GUILayoutOption[] options)
		{
			FoldBoxStyle.padding.bottom = 7;
			EditorGUILayout.BeginVertical(FoldBoxStyle, options);
			GUILayout.Label(label, FoldBoxHeadStyle, options);
		}

		public static void EndBox()
		{
			EditorGUILayout.EndVertical();
		}

		/// <summary>returns state of toggle</summary>
		public static bool Toggle(bool active, string label, Color? activeColor = null, params GUILayoutOption[] options)
		{
			Color c = GUI.backgroundColor;
			if (active) GUI.backgroundColor = (activeColor == null ? DefaultToggleButtonOnColor : activeColor.Value);
			if (GUILayout.Button(label, options)) active = !active;
			GUI.backgroundColor = c;
			return active;
		}

		/// <summary>render state of toggle but return true/false depending on click</summary>
		public static bool ToggleButton(bool active, string label, GUIStyle style, params GUILayoutOption[] options)
		{
			bool new_value = active;
			if (string.IsNullOrEmpty(label)) new_value = GUILayout.Toggle(active, GUIContent.none, style, options);
			else new_value = GUILayout.Toggle(active, label, style, options);
			return (new_value != active);
		}

		public static bool ActiveButton(Texture icon, bool isActive, GUIStyle normalStyle, GUIStyle activeStyle, int width = 64, int height = 64)
		{
			if (GUILayout.Button(icon, (isActive ? activeStyle : normalStyle), GUILayout.MinWidth(width), GUILayout.MaxWidth(width), GUILayout.MinHeight(height), GUILayout.MaxHeight(height))) return true;
			return false;
		}

		public static bool ActiveButton(Rect r, Texture icon, string label, bool isActive, GUIStyle normalStyle, GUIStyle activeStyle)
		{
			if (GUI.Button(r, icon, (isActive ? activeStyle : normalStyle))) return true;
			if (!string.IsNullOrEmpty(label))
			{
				r.y += r.height - 15; r.height = 15;
				GUI.Label(r, label, EditorStyles.whiteMiniLabel);
			}
			return false;
		}

		public static bool ActiveButton(Rect r, Texture icon, bool isActive, GUIStyle normalStyle, GUIStyle activeStyle)
		{
			return ActiveButton(r, icon, null, isActive, normalStyle, activeStyle);
		}

		private static List<string> layers;
		private static List<int> layerNumbers;
		private static string[] layerNames;
		private static long lastUpdateTick;
		public static LayerMask LayerMaskField(string label, LayerMask selected, bool showSpecial)
		{
			if (layers == null || (System.DateTime.Now.Ticks - lastUpdateTick > 10000000L && Event.current.type == EventType.Layout))
			{
				lastUpdateTick = System.DateTime.Now.Ticks;
				if (layers == null)
				{
					layers = new List<string>();
					layerNumbers = new List<int>();
					layerNames = new string[4];
				}
				else
				{
					layers.Clear();
					layerNumbers.Clear();
				}

				int emptyLayers = 0;
				for (int i = 0; i < 32; i++)
				{
					string layerName = LayerMask.LayerToName(i);

					if (layerName != "")
					{

						for (; emptyLayers > 0; emptyLayers--) layers.Add("Layer " + (i - emptyLayers));
						layerNumbers.Add(i);
						layers.Add(layerName);
					}
					else
					{
						emptyLayers++;
					}
				}

				if (layerNames.Length != layers.Count)
				{
					layerNames = new string[layers.Count];
				}
				for (int i = 0; i < layerNames.Length; i++) layerNames[i] = layers[i];
			}

			selected.value = EditorGUILayout.MaskField(label, selected.value, layerNames);

			return selected;
		}

		#endregion
		// ================================================================================================================
		#region Line/Rect/Grid/etc drawing

		public static Rect DrawFilledRect(Rect r, Color color, bool applyLayout = false, float paddingLeft = 0f, float paddingRight = 0f, float paddingTop = 0f, float paddingBottom = 0f, bool expandWidth = false, bool expandHeight = false)
		{
			if (applyLayout)
			{
				r = GUILayoutUtility.GetRect(r.width + paddingLeft + paddingRight, r.height + paddingTop + paddingBottom, GUILayout.ExpandWidth(expandWidth), GUILayout.ExpandHeight(expandHeight));
				r.width = r.width - paddingLeft - paddingRight;
				r.height = r.height - paddingTop - paddingBottom;
				r.x += paddingLeft;
				r.y += paddingTop;
			}

			if (Event.current.type == EventType.Repaint)
			{
				Color c = GUI.color;
				GUI.color = color;
				GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
				GUI.color = c;
			}

			return r;
		}

		public static void DrawHorizontalLine(float thickness, Color color, float paddingTop = 0f, float paddingBottom = 0f)
		{
			GUILayoutUtility.GetRect(0f, (thickness + paddingTop + paddingBottom), GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(false));
			if (Event.current.type == EventType.Repaint)
			{
				Color c = GUI.color;
				GUI.color = color;
				Rect r = GUILayoutUtility.GetLastRect();
				r.y += paddingTop;
				r.height = thickness;
				GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
				GUI.color = c;
			}
		}

		public static void DrawVerticalLine(float thickness, Color color, float paddingLeft = 0f, float paddingRight = 0f)
		{
			GUILayoutUtility.GetRect((thickness + paddingLeft + paddingRight), 0f, GUILayout.ExpandWidth(false), GUILayout.ExpandHeight(true));
			if (Event.current.type == EventType.Repaint)
			{
				Color c = GUI.color;
				GUI.color = color;
				Rect r = GUILayoutUtility.GetLastRect();
				r.x += paddingLeft;
				r.width = thickness;
				GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
				GUI.color = c;
			}
		}

		public static void DrawGrid(int width, int length, float cellSize, Color color)
		{
			GUILayoutUtility.GetRect(width * cellSize + cellSize, length * cellSize + cellSize);
			if (Event.current.type == EventType.Repaint)
			{
				Color c = GUI.color;
				GUI.color = color;
				Rect r = new Rect();
				r.y = 0f; r.width = 1f;
				r.height = length * cellSize;
				for (int x = 0; x <= width; x++)
				{
					r.x = x * cellSize;
					GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
				}

				r.x = 0f; r.height = 1f;
				r.width = width * cellSize;
				for (int y = 0; y <= length; y++)
				{
					r.y = y * cellSize;
					GUI.DrawTexture(r, EditorGUIUtility.whiteTexture);
				}

				GUI.color = c;
			}
		}

		#endregion
		// ================================================================================================================
		#region 3D drawing, using Handles (these are normally used in the editor scene view)

		public static void SceneDrawRect(Vector3 centerPos, float width, float length, Color color, Color outlineColor)
		{
			width /= 2f; length /= 2f;
			Vector3[] v = new Vector3[] {	new Vector3(centerPos.x - width,centerPos.y,centerPos.z - length),
											new Vector3(centerPos.x - width,centerPos.y,centerPos.z + length),
											new Vector3(centerPos.x + width,centerPos.y,centerPos.z + length),
											new Vector3(centerPos.x + width,centerPos.y,centerPos.z - length)};
			Handles.DrawSolidRectangleWithOutline(v, color, outlineColor);
		}

		public static void SceneDrawRects(int xyCount, Vector3 centerPos, float rectWidth, float rectLength, Color color, Color outlineColor)
		{
			centerPos -= new Vector3(xyCount/2 * (rectWidth), 0f, xyCount/2 * (rectLength));
			Vector3 pos = centerPos;

			for (int x = 0; x < xyCount; x++)
			{
				for (int y = 0; y < xyCount; y++)
				{
					SceneDrawRect(pos, rectWidth, rectLength, color, outlineColor);
					pos.z += rectLength;
				}
				pos.x += rectWidth;
				pos.z = centerPos.z;
			}
		}

		public static void SceneDrawGrid(Vector3 pos, int width, int length, float cellSize, Color color, Color? outlineColor = null)
		{
			Color c = Handles.color;
			Handles.color = (outlineColor != null ? outlineColor.Value : color);

			Handles.DrawLine(pos, pos + new Vector3(width * cellSize, 0f, 0f));
			Handles.DrawLine(pos, pos + new Vector3(0f, 0f, length * cellSize));
			Handles.DrawLine(pos + new Vector3(width * cellSize, 0f, length * cellSize), pos + new Vector3(width * cellSize, 0f, 0f));
			Handles.DrawLine(pos + new Vector3(width * cellSize, 0f, length * cellSize), pos + new Vector3(0f, 0f, length * cellSize));

			Handles.color = color;
			for (int x = 1; x < width; x++)
			{
				Handles.DrawLine(pos + new Vector3(x * cellSize, 0f, 0f), pos + new Vector3(x * cellSize, 0f, length * cellSize));
			}
			for (int y = 1; y < length; y++)
			{
				Handles.DrawLine(pos + new Vector3(0f, 0f, y * cellSize), pos + new Vector3(width * cellSize, 0f, y * cellSize));
			}

			Handles.color = c;
		}

		#endregion
		// ================================================================================================================
	}
}