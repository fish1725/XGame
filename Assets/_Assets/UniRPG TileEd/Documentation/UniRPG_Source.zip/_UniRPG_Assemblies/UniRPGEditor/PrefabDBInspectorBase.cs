// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class PrefabDBInspectorBase : InspectorBase<PrefabDB>
	{
		// ================================================================================================================
		#region inspector gui

		//[MenuItem("UniRPG/TileEd/Create PrefabDB", false, 101)]
		[MenuItem("GameObject/Create Other/UniRPG TileEd/PrefabDB")]
		public static void CreateNew()
		{
			Selection.activeGameObject = null;
			GameObject go = new GameObject();
			go.name = "PrefabDB";
			go.AddComponent<PrefabDB>();
			Selection.activeGameObject = go;
			PrefabDBEditor.ShowEditor();
		}

		public override void OnInspectorGUI()
		{
			//DrawDefaultInspector();
			UniRPGEditorBase.CheckGUISkin();
			EditorGUILayout.Space();

			EditorGUILayout.BeginVertical(PLYEditorUtil.BoxStyle, GUILayout.ExpandWidth(true));
			{
				EditorGUILayout.Space();

				EditorGUILayout.LabelField("Tile Sets: ", Target.tiles.Count.ToString());
				EditorGUILayout.LabelField("Auto-Tile Sets: ", Target.autoTiles.Count.ToString());
				EditorGUILayout.LabelField("Plop Sets: ", Target.plopSets.Count.ToString());

				PLYEditorUtil.DrawHorizontalLine(1f, PLYEditorUtil.LineColor, 10f, 5f);
				if (GUILayout.Button("Edit PrefabDB")) PrefabDBEditor.ShowEditor();
				EditorGUILayout.Space();
			}
			EditorGUILayout.EndVertical();
		}

		#endregion
		// ================================================================================================================
	}
}