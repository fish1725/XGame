// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class PrefabDBEditor : EditorWindow
	{
		// ================================================================================================================

		public static PrefabDB db = null;

		private static string[] EditorAreaLabels = { "Tile Sets", "Auto-Tile Sets", "Plop Sets" };
		private enum EditorArea : int { Tiles = 0, AutoTiles, Plops }
		private static EditorArea editorArea = EditorArea.Tiles;

		private static PrefabDBTilesEditor tilesEditor = null;			// editor for the normal tile sets
		private static PrefabDBAutoTileEditor autoTileEditor = null;	// editor for the auto-tile sets
		private static PrefabDBPlopsEditor plopsEditor = null;			// editor for the plop sets

		// ================================================================================================================

		public static void ShowEditor()
		{
			if (Selection.activeGameObject != null)
			{
				PrefabDB pdb = Selection.activeGameObject.GetComponent<PrefabDB>();
				if (pdb != null)
				{
					PrefabDBEditor.db = pdb;
					InitTools();
				}
			}

			PrefabDBEditor window = EditorWindow.GetWindow<PrefabDBEditor>(false, "PrefabDB");
			window.minSize = new Vector2(800, 550);
			window.Show();
		}

		public void Update()
		{
			if (Selection.activeGameObject != null)
			{
				PrefabDB pdb = Selection.activeGameObject.GetComponent<PrefabDB>();
				if (pdb != null)
				{
					PrefabDBEditor.db = pdb;
					InitTools();
				}
			}
		}

		public void OnSelectionChange()
		{
			if (Selection.activeGameObject != null)
			{
				PrefabDB pdb = Selection.activeGameObject.GetComponent<PrefabDB>();
				if (pdb != null)
				{
					PrefabDBEditor.db = pdb;
					InitTools();
				}
			}
		}

		private static void InitTools()
		{
			if (tilesEditor == null) tilesEditor = new PrefabDBTilesEditor();
			if (autoTileEditor == null) autoTileEditor = new PrefabDBAutoTileEditor();
			if (plopsEditor == null) plopsEditor = new PrefabDBPlopsEditor();
		}

		public void OnGUI()
		{
			UniRPGEditorBase.CheckGUISkin();

			if (PrefabDBEditor.db == null)
			{
				GUILayout.Label("Please select a PrefabDB to edit.");
				return;
			}

			editorArea = (EditorArea)GUILayout.Toolbar((int)editorArea, EditorAreaLabels, GUILayout.MaxWidth(400));
			PLYEditorUtil.DrawHorizontalLine(1, PLYEditorUtil.LineColor);

			switch (editorArea)
			{
				case EditorArea.Tiles: tilesEditor.Render(this); break;
				case EditorArea.AutoTiles: autoTileEditor.Render(this); break;
				case EditorArea.Plops: plopsEditor.Render(this); break;
			}

			if (GUI.changed)
			{
				this.Repaint();
			}
		}

		// ================================================================================================================
	}
}