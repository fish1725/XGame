// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class MapCreateWindow : EditorWindow
	{
		private static UniRPG.MapKind newMap_Kind = UniRPG.MapKind.Terrain;
		private static string newMap_Name = "Map";
		private static int newMap_Width = 32;
		private static int newMap_Length = 32;
		private static float newMap_TileSize = 1f;
		private static float newMap_TileHeight = 1f;
		private static PrefabDB newMap_prefabs;

		//[MenuItem("UniRPG/TileEd/Create New Map", false, 102)]
		[MenuItem("GameObject/Create Other/UniRPG TileEd/Map")]
		public static void CreateNewMap()
		{
			Selection.activeGameObject = null;
			MapCreateWindow window = EditorWindow.GetWindow<MapCreateWindow>(false, "Create Map");
			window.minSize = new Vector2(305, 190);
			window.maxSize = new Vector2(305, 195);
			window.position = new Rect(Screen.width / 2, Screen.height / 2, 305, 170);
			window.Show();
		}

		public void OnGUI()
		{
			UniRPGEditorBase.CheckGUISkin();
			EditorGUILayout.BeginVertical(GUILayout.MaxWidth(300));

			GUILayout.Space(15);
			newMap_Name = EditorGUILayout.TextField("Name", newMap_Name);
			newMap_Kind = (UniRPG.MapKind)EditorGUILayout.EnumPopup("Kind", newMap_Kind);
			PLYEditorUtil.IntVector2Field("Map Size", "width", "length", ref newMap_Width, ref newMap_Length);
			newMap_TileSize = EditorGUILayout.FloatField("Tile Size", newMap_TileSize);
			newMap_TileHeight = EditorGUILayout.FloatField("Tile Height", newMap_TileHeight);
			newMap_prefabs = (PrefabDB)EditorGUILayout.ObjectField("PrefabDB", newMap_prefabs, typeof(PrefabDB), true);

			EditorGUILayout.Space();
			if (GUILayout.Button("Create"))
			{
				Map map = Map.CreateNewMap(newMap_Name, newMap_Kind, newMap_Width, newMap_Length, newMap_TileSize, newMap_TileHeight, newMap_prefabs);
				if (map == null)
				{	// show error message
					this.ShowNotification(new GUIContent("Invalid values"));
				}
				else
				{	// select the newly created map
					Selection.activeGameObject = map.gameObject;
					this.Close();
				}
			}

			EditorGUILayout.EndVertical();
		}

		// ================================================================================================================
	}
}