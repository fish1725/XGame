// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEditor;
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using PLYCommon;
using UniRPGRuntime;

namespace UniRPGEditor
{
	public class MapInspectorBase : InspectorBase<Map>
	{
		// ================================================================================================================
		#region vars
		private static Color SelectionColour = new Color(1f, 1f, 1f, 0.2f);
		private static Color PasteColour = new Color(1f, 0f, 0f, 0.35f);

		private static Vector3 PreviewObjectOffset = new Vector3(0f, 0.01f, 0f);

		private static bool inited = false;
		private static bool editModeOn = true;				// will do certain things only when edit mode is active
		private static GameObject UniRPGTempObjects = null;

		// used with single tile and object palcement
		private static TilePiece.Direction currDir = TilePiece.Direction.Up;
		private static GameObject currObj = null; // visual presentation of the object/tile to be placed

		private int ed_selectedSet = -1;								// selected tile set in tile painter tool
		private int ed_selectedTile = -1;								// selected tile in set
		private TilePiece.Kind ed_selectedType = TilePiece.Kind.None;	// selected tile piece in auto-tile
		
		private int ed_selectedPlopSet = -1;
		private int ed_selectedPlop = -1;
		private static bool plopToTileHeight = true;	// else, snap to grid height (only for terrain maps, since dungeon maps only have two heights)
		private static int plopSnapping = 1;			// none, grid, 1/2-grid, 1/3-grid, 1/4-grid, etc
		private static bool plopSnapColliders = false;	// adjust height colliders in same location

		private static List<int> selectBuffer = new List<int>();
		private int prevMarkX = -1, prevMarkY = -1;

		public class CopyData
		{
			public int x = 0;
			public int y = 0;
			public TilePiece.Kind kind = TilePiece.Kind.None;
			public TilePiece.Direction faceDir = TilePiece.Direction.Up;
			public int setIdx = 0;
			public int tileIdx = 0;
			public int floorLevel = 0;
			public bool fromAutoTileSet = false;
			public List<CopyData> linkedPieces = new List<CopyData>();
		}
		private static List<CopyData> copyBuffer = new List<CopyData>();

		#endregion
		// ================================================================================================================
		#region scene view gui vars

		public static Color Cursor3D_Color = new Color(0f, 0.5f, 1f, 1f);
		public static Color Cursor3D_PlaceCol = new Color(1f, 1f, 1f, 0.5f);
		public static Color Cursor3D_DelCol = new Color(0.3f, 0f, 0f, 0.5f);
		public static Color ActiveDirButton_Col = new Color(0f, 0.6f, 1f);

		private static Vector3 gridOffset = Vector3.zero;	// offset when calcualting snap position
		private bool dragOnGrid = false;					// helper to track when drawing tiles/mouse-held
		private bool onTheGrid = false;						// true while mouse over the grid
		private Vector3 cursorPos = Vector3.zero;			// position of mouse/cursor on the grid

		#endregion
		// ================================================================================================================
		#region inspector gui vars

		private static string[] ToolLabels = { "Tiles", "Auto-Tiles", "Plops" };
		private enum ToolTypes : int { Tiles=0, AutoTiles=1, Plops=2, Select=3, Paste=4 }
		private static ToolTypes selectedTool = ToolTypes.Tiles;

		private static bool forceTargetDirty = false;		// force a redraw of Target
		private static bool forceGuiDirty = false;			// force a redraw of Inspector
		private static bool[] folds = { true };				// helper for various fold & toggles

		private int brushSize = 1;							// size of brush that paints auto-tiles
		private int currentPlacementHeight = 0;				// helper which adapts when in moldingMode and might differ from Target.ed_currentLevel
		private bool autoTilesSelection = false;			// helper with Normal Tiles Tool where both Normal and Auto-Tiles are shown
		private static bool moldingMode = false;			// in this mode left click will draw raised tile and right click will draw lowered tile
		private static bool tileReplaceMode = true;			// in this mode an existing tile will be replaced when placing tiles via Normal Tile pacement tool
		private static bool floorRandomRot = true;			// random rotation of auto-tile floor?
		private static bool floorRandomTile = false;		// random floor tile from set?

		private static bool[] nTilesFolds = new bool[99];
		private static bool[] aTilesFolds = new bool[99];
		private static bool[] plopFolds = new bool[99];
		private static bool nAllFolds = false;
		private static bool aAllFolds = false;
		private static bool plopAllFolds = false;

		private static LayerMask plopColMask;

		#endregion
		// ================================================================================================================
		#region enable/disable

		public void OnEnable()
		{
			dragOnGrid = false;
			onTheGrid = false;

			gridOffset = Target.transform.position;
			gridOffset.x -= Target.tileSize / 2f;
			gridOffset.z -= Target.tileSize / 2f;

			if (!inited)
			{
				inited = true;

				//for (int i = 0; i < nTilesFolds.Length; i++)
				//{
				//	nTilesFolds[i] = false;
				//	aTilesFolds[i] = false;
				//	plopFolds[i] = false;
				//}

				// check if there is any junk left in the temp container
				// just wipe the whole container, it will be recreated later
				GameObject temp = GameObject.Find("UniRPGTempObjects");
				if (temp != null) DestroyImmediate(temp);

				// hide the wireframes on existing floor and wall pieces
				if (Target.hideWireframes)
				{
					for (int i = 0; i < Target.transform.childCount; i++)
					{
						PLYEditorUtil.HideRendererWireframe(Target.transform.GetChild(i).gameObject, true);
					}
				}

				PreviewObjectOffset = new Vector3(0f, Target.tileHeight / 50f, 0f);
			}

			// check if must respawn the preview object
			CheckCurrObj();
		}

		public void OnDisable()
		{
			inited = false;
			dragOnGrid = false;
			onTheGrid = false;

			currObj = null;
			GameObject temp = GameObject.Find("UniRPGTempObjects");
			if (temp != null) DestroyImmediate(temp);
		}

		public void OnDestroy()
		{
			currObj = null;
			GameObject temp = GameObject.Find("UniRPGTempObjects");
			if (temp != null) DestroyImmediate(temp);
		}

		#endregion
		// ================================================================================================================
		#region Misc

		private void ChangeDirection(bool toRight, bool allowAngled, bool forceUpdate)
		{
			if (toRight)
			{
					 if (currDir == TilePiece.Direction.Up) currDir = (allowAngled ? TilePiece.Direction.UpR : TilePiece.Direction.Right);
				else if (currDir == TilePiece.Direction.Right) currDir = (allowAngled ? TilePiece.Direction.DwnR : TilePiece.Direction.Down);
				else if (currDir == TilePiece.Direction.Down) currDir = (allowAngled ? TilePiece.Direction.DwnL : TilePiece.Direction.Left);
				else if (currDir == TilePiece.Direction.Left) currDir = (allowAngled ? TilePiece.Direction.UpL : TilePiece.Direction.Up);
				else if (currDir == TilePiece.Direction.UpR) currDir = TilePiece.Direction.Right;
				else if (currDir == TilePiece.Direction.DwnR) currDir = TilePiece.Direction.Down;
				else if (currDir == TilePiece.Direction.DwnL) currDir = TilePiece.Direction.Left;
				else if (currDir == TilePiece.Direction.UpL) currDir = TilePiece.Direction.Up;
			}
			else
			{
					 if (currDir == TilePiece.Direction.Up) currDir = (allowAngled ? TilePiece.Direction.UpL : TilePiece.Direction.Left);
				else if (currDir == TilePiece.Direction.Right) currDir = (allowAngled ? TilePiece.Direction.UpR : TilePiece.Direction.Up);
				else if (currDir == TilePiece.Direction.Down) currDir = (allowAngled ? TilePiece.Direction.DwnR : TilePiece.Direction.Right);
				else if (currDir == TilePiece.Direction.Left) currDir = (allowAngled ? TilePiece.Direction.DwnL : TilePiece.Direction.Down);
				else if (currDir == TilePiece.Direction.UpR) currDir = TilePiece.Direction.Up;
				else if (currDir == TilePiece.Direction.DwnR) currDir = TilePiece.Direction.Right;
				else if (currDir == TilePiece.Direction.DwnL) currDir = TilePiece.Direction.Down;
				else if (currDir == TilePiece.Direction.UpL) currDir = TilePiece.Direction.Left;
			}

			if (forceUpdate && currObj != null)
			{
				Vector3 rot = currObj.transform.localRotation.eulerAngles;
				rot.y = (float)currDir;
				currObj.transform.localRotation = Quaternion.Euler(rot);
			}
		}

		private void CheckCurrObj()
		{
			if (currObj == null && editModeOn && selectedTool == ToolTypes.Tiles)
			{
				if ( ed_selectedType != TilePiece.Kind.None && ed_selectedTile >= 0 && ed_selectedSet >= 0 && ed_selectedSet < Target.db.autoTiles.Count)
				{
					if (ed_selectedTile < Target.db.autoTiles[ed_selectedSet].tiles.Count)
					{
						DefAutoTile t = Target.db.autoTiles[ed_selectedSet].tiles[ed_selectedTile];
						if (t.pieces[(int)ed_selectedType] != null) SpawnCurrObj(t.pieces[(int)ed_selectedType].gameObject);
					}
				}
			}
		}

		private void SpawnCurrObj(GameObject fab)
		{
			// first check if there is container for these temp objects
			if (UniRPGTempObjects == null)
			{
				UniRPGTempObjects = GameObject.Find("UniRPGTempObjects");
				if (UniRPGTempObjects == null)
				{	// still null, create one now
					UniRPGTempObjects = new GameObject();
					UniRPGTempObjects.name = "UniRPGTempObjects";
				}
			}

			// wipe old temp objects
			currObj = null;
			List<GameObject> delList = new List<GameObject>();
			for (int i = 0; i < UniRPGTempObjects.transform.childCount; i++) delList.Add(UniRPGTempObjects.transform.GetChild(i).gameObject);
			foreach (GameObject go in delList) DestroyImmediate(go);
			delList.Clear();

			// just to be sure it is still centered in case user moved it around
			UniRPGTempObjects.transform.position = Vector3.zero;

			// spawn a presentation of the selected tile/object/etc
			currObj = Instantiate(fab) as GameObject;
			currObj.name = "Object_Preview";
			currObj.transform.parent = UniRPGTempObjects.transform;
			currObj.transform.position = cursorPos + PreviewObjectOffset;
			Vector3 rot = currObj.transform.localRotation.eulerAngles;
			rot.y = (float)currDir;
			currObj.transform.localRotation = Quaternion.Euler(rot);

			// turn off collider(s) for preview object
			PLYUtil.DestroyColliders(currObj);
		}

		#endregion
		// ================================================================================================================
		#region Inspector GUI

		public override void OnInspectorGUI()
		{
			UniRPGEditorBase.CheckGUISkin();
			EditorGUILayout.Space();

			// meta info
			folds[0] = PLYEditorUtil.BeginVerticalFold("Map Info", folds[0]);
			if (folds[0])
			{
				GUILayout.Label(string.Format("( {0} Map ) ( {1}x{2} => {3} tiles )", Target.kind.ToString(), Target.width, Target.length, (Target.width * Target.length)));
				Target.gizmoGrid = EditorGUILayout.Toggle("Show grid", Target.gizmoGrid);
				
				bool prev = Target.hideWireframes;
				Target.hideWireframes = EditorGUILayout.Toggle("Hide Wireframes", Target.hideWireframes);
				if (prev != Target.hideWireframes) HideWireframeFor(Target, Target.hideWireframes);

				EditorGUILayout.BeginHorizontal();
				{
					editModeOn = PLYEditorUtil.Toggle(editModeOn, "Toggle Edit Mode", null, GUILayout.MaxWidth(150));

					if (editModeOn && selectedTool == ToolTypes.Tiles)
					{
						if (GUILayout.Button("Selection Mode")) { currObj = null; selectedTool = ToolTypes.Select; selectBuffer.Clear(); }
						if (GUILayout.Button("Paste Mode")) { currObj = null; selectedTool = ToolTypes.Paste; }
					}
				}
				EditorGUILayout.EndHorizontal();
			}
			PLYEditorUtil.EndVerticalFold();
			EditorGUILayout.Space();

			// ****************************************************
			// edit mode inspector

			if (editModeOn)
			{
				if (selectedTool == ToolTypes.Select) // selection mode on
				{
					GUILayout.Label("Selection mode", EditorStyles.boldLabel);
					GUILayout.Label("Mark the tiles to copy.");
					EditorGUILayout.Space();
					EditorGUILayout.BeginHorizontal();
					{
						if (GUILayout.Button("Cancel")) selectedTool = ToolTypes.Tiles;
						if (GUILayout.Button("Copy")) 
						{
							selectedTool = ToolTypes.Tiles;
							copyBuffer.Clear();

							// precalc x/y offset to make pasting easier
							int lX = 999999,lY=999999;
							foreach (int idx in selectBuffer)
							{
								int y = idx / Target.width;
								int x = idx - (y * Target.width);
								if (y < lY || x < lX) { lY = y; lX = x; }
							}

							// create buffer
							foreach (int idx in selectBuffer)
							{
								CopyData d = new CopyData();
								d.y = idx / Target.width;
								d.x = idx - (d.y * Target.width);
								d.y -= lY; d.x -= lX;
								if (Target.tiles[idx] != null)
								{
									TilePiece tile = Target.tiles[idx].GetComponent<TilePiece>();
									d.kind = tile.kind;
									d.faceDir = tile.faceDir;
									d.setIdx = tile.setIdx;
									d.tileIdx = tile.tileIdx;
									d.floorLevel = tile.floorLevel;
									d.fromAutoTileSet = tile.fromAutoTileSet;

									if (tile.linkedPieces!=null)
									{
										foreach (GameObject go in tile.linkedPieces)
										{
											if (go != null)
											{
												CopyData d2 = new CopyData();
												d2.y = d.y;
												d2.x = d.x;
												TilePiece tile2 = go.GetComponent<TilePiece>();
												d2.kind = tile2.kind;
												d2.faceDir = tile2.faceDir;
												d2.setIdx = tile2.setIdx;
												d2.tileIdx = tile2.tileIdx;
												d2.floorLevel = tile2.floorLevel;
												d2.fromAutoTileSet = tile2.fromAutoTileSet;
												d.linkedPieces.Add(d2);
											}
										}
									}
								}
								copyBuffer.Add(d);
							}
						}
					}
					EditorGUILayout.EndHorizontal();
					return;
				}
				else if (selectedTool == ToolTypes.Paste) // paste mode on
				{
					GUILayout.Label("Paste mode", EditorStyles.boldLabel);
					GUILayout.Label("Click in the map to paste.");
					EditorGUILayout.Space();
					if (GUILayout.Button("Done")) selectedTool = ToolTypes.Tiles;
					return;
				}

				ToolTypes prev = selectedTool;
				selectedTool = (ToolTypes)GUILayout.Toolbar((int)selectedTool, ToolLabels);

				if (prev != selectedTool && (selectedTool == ToolTypes.Plops || prev == ToolTypes.Plops))
				{	// reset the plops when entering its tool from another
					ed_selectedPlopSet = -1;
					ed_selectedPlop = -1;
					if (currObj != null) DestroyImmediate(currObj);
				}

				GUILayout.BeginVertical(PLYEditorUtil.BoxStyle);
				{
					GUILayout.Label("Options", EditorStyles.boldLabel);
					EditorGUILayout.BeginHorizontal();
					{
						if (selectedTool == ToolTypes.Plops)
						{
							GUI.enabled = false;
							EditorGUILayout.IntField("Brush Size:", 1, GUILayout.MaxWidth(200));
						}
						else
						{
							brushSize = EditorGUILayout.IntField("Brush Size:", brushSize, GUILayout.MaxWidth(200));
						}
						if (GUILayout.Button("-", EditorStyles.miniButtonLeft, GUILayout.Width(25))) { brushSize--; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						if (GUILayout.Button("+", EditorStyles.miniButtonMid, GUILayout.Width(25))) { brushSize++; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						GUILayout.Space(2);
						if (GUILayout.Button("r", EditorStyles.miniButtonRight, GUILayout.Width(25))) { brushSize = 1; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true;
					}
					EditorGUILayout.EndHorizontal();

					// tile options (different height tiles are only supported on terrain maps, not dungeon and world maps)
					if (Target.kind == UniRPG.MapKind.Terrain)
					{
						EditorGUILayout.BeginHorizontal();
						{
							Target.ed_currentLevel = EditorGUILayout.IntField("Draw Height Level:", Target.ed_currentLevel, GUILayout.MaxWidth(200));
							if (GUILayout.Button("-", EditorStyles.miniButtonLeft, GUILayout.Width(25))) { Target.ed_currentLevel--; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
							if (GUILayout.Button("+", EditorStyles.miniButtonMid, GUILayout.Width(25))) { Target.ed_currentLevel++; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
							GUILayout.Space(2);
							if (GUILayout.Button("r", EditorStyles.miniButtonRight, GUILayout.MaxWidth(25))) { Target.ed_currentLevel = 0; forceTargetDirty = true; PLYEditorUtil.FocusSceneView(); }
						}
						EditorGUILayout.EndHorizontal();

						if (selectedTool == ToolTypes.AutoTiles)
						{
							moldingMode = EditorGUILayout.Toggle("Raise/Lower Mode:", moldingMode);
						}
					}

					if (selectedTool == ToolTypes.Tiles)
					{
						tileReplaceMode = EditorGUILayout.Toggle("Replace Existing:", tileReplaceMode);
					}
					else if (selectedTool == ToolTypes.AutoTiles)
					{
						if (ed_selectedSet >= 0 && ed_selectedSet < Target.db.autoTiles.Count)
						{
							if (Target.db.autoTiles[ed_selectedSet].kind == UniRPG.TileSetKind.Expanding)
							{
								tileReplaceMode = EditorGUILayout.Toggle("Replace Existing:", tileReplaceMode);
							}
							else
							{
								GUI.enabled = false;
								EditorGUILayout.Toggle("Replace Existing:", true);
								GUI.enabled = true;
							}

							if (Target.db.autoTiles[ed_selectedSet].kind == UniRPG.TileSetKind.Dungeon)
							{
								floorRandomRot = EditorGUILayout.Toggle("Floor Random Rotation:", floorRandomRot);
								floorRandomTile = EditorGUILayout.Toggle("Floor Random Tile:", floorRandomTile);
							}
							else if (Target.db.autoTiles[ed_selectedSet].kind == UniRPG.TileSetKind.Terrain)
							{
								if (Target.db.autoTiles[ed_selectedSet].is_4_tile_system)
								{
									floorRandomRot = EditorGUILayout.Toggle("Floor Random Rotation:", floorRandomRot);
								}
								else
								{
									GUI.enabled = false;
									EditorGUILayout.Toggle("Floor Random Rotation:", false);
									GUI.enabled = true;
								}

								floorRandomTile = EditorGUILayout.Toggle("Floor Random Tile:", floorRandomTile);
							}
							else
							{
								GUI.enabled = false;
								EditorGUILayout.Toggle("Floor Random Rotation:", false);
								EditorGUILayout.Toggle("Floor Random Tile:", false);
								GUI.enabled = true;
							}
						}
						else
						{
							GUI.enabled = false;
							EditorGUILayout.Toggle("Replace Existing:", true);
							EditorGUILayout.Toggle("Floor Random Rotation:", false);
							GUI.enabled = true;
						}

					}

					if (selectedTool != ToolTypes.AutoTiles) 
					{ 
						EditorGUILayout.Space();
						DrawDirectionButtons(selectedTool == ToolTypes.Plops);
					}

					if (selectedTool == ToolTypes.Plops)
					{
						GUILayout.Label("Snapping:", EditorStyles.boldLabel);
						EditorGUILayout.BeginHorizontal();
						{
							if (PLYEditorUtil.ToggleButton((plopSnapping == 0), "None", EditorStyles.miniButtonLeft, GUILayout.Width(60))) { plopSnapping = 0; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 1), "Tile", EditorStyles.miniButtonMid, GUILayout.Width(60))) { plopSnapping = 1; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 2), "1/2-Tile", EditorStyles.miniButtonMid, GUILayout.Width(60))) { plopSnapping = 2; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 3), "1/3-Tile", EditorStyles.miniButtonMid, GUILayout.Width(60))) { plopSnapping = 3; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton((plopSnapping == 4), "1/4-Tile", EditorStyles.miniButtonRight, GUILayout.Width(60))) { plopSnapping = 4; PLYEditorUtil.FocusSceneView(); }
						}
						EditorGUILayout.EndHorizontal();
						EditorGUILayout.Space();
						EditorGUILayout.BeginHorizontal();
						{
							EditorGUILayout.PrefixLabel("Snap Height:");
							if (PLYEditorUtil.ToggleButton(plopToTileHeight, "Tiles", EditorStyles.miniButtonLeft, GUILayout.Width(60))) { plopToTileHeight = true; PLYEditorUtil.FocusSceneView(); }
							if (PLYEditorUtil.ToggleButton(!plopToTileHeight, "Grid", EditorStyles.miniButtonRight, GUILayout.Width(60))) { plopToTileHeight = false; PLYEditorUtil.FocusSceneView(); }
						}
						EditorGUILayout.EndHorizontal();
						plopSnapColliders = EditorGUILayout.Toggle("Snap height to colliders:", plopSnapColliders);
						//plopColMask = EditorGUILayout.LayerField("Colliders Mask", plopColMask);
						plopColMask = PLYEditorUtil.LayerMaskField("Colliders Mask", plopColMask, true);
					}

					// draw the sets
					switch (selectedTool)
					{
						case ToolTypes.Tiles: DrawTileSetsAndTileTypeOfKind(Target.kind); break;
						case ToolTypes.AutoTiles: DrawAutoTileSetsOfKind(Target.kind); break;
						case ToolTypes.Plops: DrawPlopSelection(Target.kind);  break;
					}

					// some buttons
					PLYEditorUtil.DrawHorizontalLine(1f, PLYEditorUtil.LineColor, 10f, 5f);
					EditorGUILayout.BeginHorizontal();
					{
						if (selectedTool == ToolTypes.Tiles || selectedTool == ToolTypes.AutoTiles)
						{
							if (ed_selectedSet == -1 || ed_selectedTile == -1) GUI.enabled = false;
							if (GUILayout.Button("Flood Fill", GUILayout.MaxWidth(100)))
							{	// spawn floor tiles and hide the wireframes of each

								//Undo.RegisterSceneUndo("Flood Fill");
								if (selectedTool == ToolTypes.AutoTiles)
								{
									ed_selectedType = TilePiece.Kind.Floor;
									Target.FloodFillAutoTile(Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, ed_selectedType);
								}
								else if (selectedTool == ToolTypes.Tiles)
								{
									if (autoTilesSelection) Target.FloodFillAutoTile(Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, ed_selectedType, currDir);
									else Target.FloodFillTile(Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, currDir);
								}

								if (Target.hideWireframes)
								{
									for (int i = 0; i < Target.transform.childCount; i++) PLYEditorUtil.HideRendererWireframe(Target.transform.GetChild(i).gameObject, true);
								}
							}

							GUI.enabled = true;
							if (GUILayout.Button("Remove All Tiles", GUILayout.MaxWidth(120)))
							{
								//Undo.RegisterSceneUndo("Remove All Tiles");
								Target.RemoveAllTiles();
							}
						}

						if (GUILayout.Button("Edit PrefabDB", GUILayout.MaxWidth(120)))
						{
							Selection.activeGameObject = Target.db.gameObject;
							PrefabDBEditor.ShowEditor();
						}

					}
					EditorGUILayout.EndHorizontal();

				}
				EditorGUILayout.Space();
				GUILayout.EndVertical();
			}

			// ****************************************************

			if (GUI.changed || forceTargetDirty)
			{
				if (brushSize < 1) brushSize = 1; // dungeon supports only size-1 brushes
				else if (brushSize > 5) brushSize = 5;
				
				forceTargetDirty = false;
				EditorUtility.SetDirty(Target);
			}
		}

		private void DrawDirectionButtons(bool allowAngled)
		{
			if (currDir == TilePiece.Direction.Invalid || (!allowAngled && currDir != TilePiece.Direction.Up && currDir != TilePiece.Direction.Down && currDir != TilePiece.Direction.Right && currDir != TilePiece.Direction.Left))
			{
				currDir = TilePiece.Direction.Up;
			}

			TilePiece.Direction prevDir = currDir;
			EditorGUILayout.BeginHorizontal();
			{
				EditorGUILayout.PrefixLabel("Direction:");

				EditorGUILayout.BeginVertical();
				{
					if (GUILayout.Button(UniRPGEditorBase.Rotate_Icon, GUILayout.Width(35))) { ChangeDirection(true, allowAngled, false); PLYEditorUtil.FocusSceneView(); }
					GUILayout.Label(currDir.ToString(), EditorStyles.miniLabel);
				}
				EditorGUILayout.EndVertical();
				GUILayout.Space(10);

				EditorGUILayout.BeginVertical(GUILayout.Width(60));
				{
					EditorGUILayout.BeginHorizontal();
					{
						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.UpL ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.UpL), null, PLYEditorUtil.MiniButtonLeftNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.UpL; PLYEditorUtil.FocusSceneView(); }

						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Up ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Up), null, PLYEditorUtil.MiniButtonMidNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Up; PLYEditorUtil.FocusSceneView(); }

						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.UpR ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.UpR), null, PLYEditorUtil.MiniButtonRightNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.UpR; PLYEditorUtil.FocusSceneView(); }
					}
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.BeginHorizontal();
					{
						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Left ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Left), null, PLYEditorUtil.MiniButtonLeftNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Left; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = false; GUI.backgroundColor = Color.white;
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Invalid), null, PLYEditorUtil.MiniButtonMidNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Invalid; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Right ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Right), null, PLYEditorUtil.MiniButtonRightNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Right; PLYEditorUtil.FocusSceneView(); }
					}
					EditorGUILayout.EndHorizontal();
					EditorGUILayout.BeginHorizontal();
					{
						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.DwnL ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.DwnL), null, PLYEditorUtil.MiniButtonLeftNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.DwnL; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true; GUI.backgroundColor = (currDir == TilePiece.Direction.Down ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.Down), null, PLYEditorUtil.MiniButtonMidNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.Down; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = allowAngled; GUI.backgroundColor = (currDir == TilePiece.Direction.DwnR ? ActiveDirButton_Col : Color.white);
						if (PLYEditorUtil.ToggleButton((currDir == TilePiece.Direction.DwnR), null, PLYEditorUtil.MiniButtonRightNoMarginStyle, GUILayout.Height(14), GUILayout.Width(14))) { currDir = TilePiece.Direction.DwnR; PLYEditorUtil.FocusSceneView(); }
						GUI.enabled = true; GUI.enabled = true; GUI.backgroundColor = Color.white;
					}
					EditorGUILayout.EndHorizontal();
				}
				EditorGUILayout.EndVertical();
				GUILayout.FlexibleSpace();
			}
			EditorGUILayout.EndHorizontal();	

			// update object rotation
			if (currObj != null && currDir != prevDir)
			{
				Vector3 rot = currObj.transform.localRotation.eulerAngles;
				rot.y = (float)currDir;
				currObj.transform.localRotation = Quaternion.Euler(rot);
			}
		}

		#endregion
		// ================================================================================================================
		#region Inspector GUI - Tool 2: Plops

		private void DrawPlopSelection(UniRPG.MapKind mapKind)
		{
			EditorGUILayout.Space();
			bool drawNothing = true;
			bool setWasPresent = false; // helper to check if the set selected set can be used (so can auto deselect it if needed)
			bool isFirst = true;

			if (Target.db.plopSets.Count > 0)
			{
				bool prev = plopAllFolds;
				if (prev != (plopAllFolds = GUILayout.Toggle(plopAllFolds, "* All", EditorStyles.toggleGroup)))
				{
					for (int i = 0; i < plopFolds.Length; i++) plopFolds[i] = plopAllFolds;
				}

				for (int setIdx = 0; setIdx < Target.db.plopSets.Count; setIdx++ )
				{
					if ((Target.db.plopSets[setIdx].allowedMapsMask & mapKind) == mapKind)
					{
						DrawPlopSetSelectionBar(Target.db.plopSets[setIdx], setIdx, (isFirst?1:0));
						if (ed_selectedPlopSet == setIdx) setWasPresent = true;
						isFirst = false;
						drawNothing = false;
					}
				}
			}

			if (!setWasPresent)
			{
				ed_selectedPlopSet = -1;
				ed_selectedPlop = -1;
			}

			if (drawNothing) GUILayout.Label("No sets defined", PLYEditorUtil.WarningLabelStyle);
		}

		private void DrawPlopSetSelectionBar(DefPlopSet set, int setIdx, int blankPlop)
		{
			//GUILayout.Label(set.name, EditorStyles.boldLabel);
			plopFolds[setIdx] = GUILayout.Toggle(plopFolds[setIdx], set.name, EditorStyles.toggleGroup);
			if (!plopFolds[setIdx]) return;

			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label

			// calc the space avail for drawing the thumbs
			float spaceWidth = Screen.width - 25;

			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt((set.plops.Count + blankPlop) / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			bool showErr = true;
			float startX = r.x;
			float startY = r.y;

			if (set.plops.Count > 0)
			{
			    r.width = 64; r.height = 64;
			    int column = 0;

				if (blankPlop == 1)
				{
					if (PLYEditorUtil.ActiveButton(r, null, "clear", (ed_selectedPlopSet == -1 && ed_selectedPlop == -1), UniRPGEditorBase.IconToggleButtonOffStyle, UniRPGEditorBase.IconToggleButtonOnStyle))
					{
						ed_selectedPlopSet = -1;
						ed_selectedPlop = -1;
						if (currObj != null) DestroyImmediate(currObj);
						PLYEditorUtil.FocusSceneView();
					}

					column++; r.x += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right;
					if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom; }
				}

				// show the buttons for selection of plops in this set
				for (int j = 0; j < set.plops.Count; j++)
				{
					if (set.plops[j] != null)
					{
						Plop p = set.plops[j].GetComponent<Plop>();
						if (p != null)
						{
							if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
							if (PLYEditorUtil.ActiveButton(r, p._preview, p.name, (ed_selectedPlopSet == setIdx && ed_selectedPlop == j), UniRPGEditorBase.IconToggleButtonOffStyle, UniRPGEditorBase.IconToggleButtonOnStyle))
							{
								ed_selectedPlopSet = setIdx;
								ed_selectedPlop = j;
								SpawnCurrObj(p.gameObject);
								PLYEditorUtil.FocusSceneView();
							}

							showErr = false;
							column++; r.x += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right;
							if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom; }
						}
					}
				}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid plops defined for this set", PLYEditorUtil.WarningLabelStyle);
			}
		}

		#endregion
		// ================================================================================================================
		#region Inspector GUI - Tool 0: Tiles and Tool 1: AutoTile

		private void DrawAutoTileSetsOfKind(UniRPG.MapKind mapKind)
		{
			EditorGUILayout.Space();
			bool drawNothing = true;

			if (Target.db.autoTiles.Count > 0)
			{
				bool prev = aAllFolds;
				if (prev != (aAllFolds = GUILayout.Toggle(aAllFolds, "* All", EditorStyles.toggleGroup)))
				{
					for (int i = 0; i < aTilesFolds.Length; i++) aTilesFolds[i] = aAllFolds;
				}

				for (int i = 0; i < Target.db.autoTiles.Count; i++)
				{
					if ((Target.db.autoTiles[i].allowedMapsMask & mapKind) == mapKind)
					{
						// if a default set was not selected yet, select one now
						//if (ed_selectedSet == -1) ed_selectedSet = i;

						drawNothing = false;
						DrawAutoTileSetSelectionBar(Target.db.autoTiles[i], i);
					}
				}
			}

			if (drawNothing) GUILayout.Label("No tile sets defined", PLYEditorUtil.WarningLabelStyle);
		}

		private void DrawTileSetsAndTileTypeOfKind(UniRPG.MapKind mapKind)
		{
			EditorGUILayout.Space();
			bool drawNothing = true;

			if (Target.db.tiles.Count > 0)
			{
				bool prev = nAllFolds;
				if (prev != (nAllFolds = GUILayout.Toggle(nAllFolds, "* All", EditorStyles.toggleGroup)))
				{
					for (int i = 0; i < nTilesFolds.Length; i++) nTilesFolds[i] = nAllFolds;
				}

				for (int i = 0; i < Target.db.tiles.Count; i++)
				{
					if ((Target.db.tiles[i].allowedMapsMask & mapKind) == mapKind)
					{
						// if a default set was not selected yet, select one now
						if (ed_selectedSet == -1)
						{
							autoTilesSelection = false;
							ed_selectedSet = i;
						}
						drawNothing = false;
						DrawTilesSelectionBar(Target.db.tiles[i], i);
					}
				}
			}

			if (Target.db.autoTiles.Count > 0)
			{				
				for (int i = 0; i < Target.db.autoTiles.Count; i++)
				{
					if ((Target.db.autoTiles[i].allowedMapsMask & mapKind) == mapKind)
					{
						// if a default set was not selected yet, select one now
						if (ed_selectedSet == -1)
						{
							autoTilesSelection = true;
							ed_selectedSet = i;
						}
						drawNothing = false;
						DrawAutoTileSetAndPiecesSelectionBar(Target.db.autoTiles[i], i);
					}
				}
			}

			if (drawNothing) GUILayout.Label("No tile sets defined", PLYEditorUtil.WarningLabelStyle);
		}

		private void DrawAutoTileSetSelectionBar(DefAutoTileSet set, int setId)
		{
			//GUILayout.Label(set.name, EditorStyles.boldLabel);
			aTilesFolds[setId] = GUILayout.Toggle(aTilesFolds[setId], set.name, EditorStyles.toggleGroup);
			if (!aTilesFolds[setId]) return;

			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label

			// calc the space avail for drawing the tile thumbs. 15 = space taken by padding and colour bit
			//float spaceWidth = Screen.width - (r.x * 2) - 15;
			float spaceWidth = Screen.width - 25;

			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(set.tiles.Count / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			bool showErr = true;
			float startX = r.x;
			float startY = r.y;

			if (set.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;

				// show the buttons for selection of tile variations in this set
				for (int j = 0; j < set.tiles.Count; j++)
				{
					if (set.tiles[j].pieces[(int)TilePiece.Kind.Floor] != null)
					{
						TilePiece p = set.tiles[j].pieces[(int)TilePiece.Kind.Floor].GetComponent<TilePiece>();
						if (p != null)
						{
							// if no tile is yet selected, select a default one now
							if (ed_selectedTile == -1) ed_selectedTile = j;

							// show tile
							if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
							if (PLYEditorUtil.ActiveButton(r, p._preview, (ed_selectedSet == setId && ed_selectedTile == j), UniRPGEditorBase.IconToggleButtonOffStyle, UniRPGEditorBase.IconToggleButtonOnStyle))
							{
								ed_selectedSet = setId;
								ed_selectedTile = j;
							}

							showErr = false;
							column++; r.x += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right;
							if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom; }
						}

					}
				}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
			}

			// if no tile could be selected then unselect set too (negating what auto selection of set might have done)
			if (ed_selectedTile == -1) ed_selectedSet = -1;
		}

		private void DrawAutoTileSetAndPiecesSelectionBar(DefAutoTileSet set, int setId)
		{
			//GUILayout.Label(set.name, EditorStyles.boldLabel);
			nTilesFolds[setId] = GUILayout.Toggle(nTilesFolds[setId], set.name, EditorStyles.toggleGroup);
			if (!nTilesFolds[setId]) return;

			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label

			// calc the space avail for drawing the tile thumbs. 15 = space taken by padding and colour bit
			//float spaceWidth = Screen.width - (r.x * 2) - 15;
			float spaceWidth = Screen.width - 25;

			bool showErr = true;
			int piecesCount = set.tiles.Count;
			for (int j = 0; j < set.tiles.Count; j++)
				for (int pieceIdx = 0; pieceIdx < set.tiles[j].pieces.Length; pieceIdx++)
				{
					if (set.tiles[j].pieces[pieceIdx] != null)
					{
						showErr = false; if (pieceIdx != 0) piecesCount++; // dont count floor (idx = 0)
					}
				}

			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(piecesCount / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			float startX = r.x;
			float startY = r.y;

			if (set.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;

				// show the buttons for selection of tile variations in this set
				for (int j = 0; j < set.tiles.Count; j++)
					for (int pieceIdx = 0; pieceIdx < set.tiles[j].pieces.Length; pieceIdx++)
					{
						r = DrawTilePieceButton(r, set.tiles[j].pieces[pieceIdx], true, setId, j, (TilePiece.Kind)pieceIdx, ref column, columns, startX);
					}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
			}

			// if no tile could be selected then unselect set too (negating what auto selection of set might have done)
			if (ed_selectedTile == -1) ed_selectedSet = -1;
		}

		private void DrawTilesSelectionBar(DefTileSet set, int setId)
		{
			//GUILayout.Label(set.name, EditorStyles.boldLabel);
			nTilesFolds[setId] = GUILayout.Toggle(nTilesFolds[setId], set.name, EditorStyles.toggleGroup);
			if (!nTilesFolds[setId]) return;

			Rect r = GUILayoutUtility.GetLastRect();
			r.y += r.height + 3; // continue under the label
			float spaceWidth = Screen.width - 25;
			bool showErr = true;
			int piecesCount = set.tiles.Count;
			int columns = Mathf.FloorToInt(spaceWidth / (64f + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right));
			if (columns < 1) columns = 1;
			int rows = Mathf.CeilToInt(piecesCount / (float)columns);
			if (rows < 1) rows = 1;
			r.height = (rows * (64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom)) + 4;

			// allocated space in layout engine, for the controls to follow which will be manually positioned
			r = GUILayoutUtility.GetRect(r.width, r.height);
			GUI.Box(r, GUIContent.none);

			r.x += 2; r.y += 2; r.height -= 4; r.width = 7;
			PLYEditorUtil.DrawFilledRect(r, set.editorColor);
			r.x += r.width + 3; r.y += 1;

			float startX = r.x;
			float startY = r.y;

			if (set.tiles.Count > 0)
			{
				r.width = 64; r.height = 64;
				int column = 0;

				// show the buttons for selection of tile variations in this set
				for (int j = 0; j < set.tiles.Count; j++)
				{
					showErr = false;
					r = DrawTilePieceButton(r, set.tiles[j], false, setId, j, TilePiece.Kind.None, ref column, columns, startX);
				}
			}

			if (showErr)
			{
				r.width = spaceWidth; r.x = startX; r.y = startY;
				GUI.Label(r, "No valid tiles defined for this set", PLYEditorUtil.WarningLabelStyle);
			}

			// if no tile could be selected then unselect set too (negating what auto selection of set might have done)
			if (ed_selectedTile == -1) ed_selectedSet = -1;
		}

		private Rect DrawTilePieceButton(Rect r, GameObject piece, bool isAutoTile, int setId, int tileId, TilePiece.Kind tileType, ref int column, int columns, float startX)
		{
			if (piece != null)
			{
				TilePiece p = piece.GetComponent<TilePiece>();
				if (p != null)
				{
					// if no tile is yet selected, select a default one now
					if (ed_selectedTile == -1)
					{
						ed_selectedTile = tileId;
						ed_selectedType = tileType;
					}

					// show floor piece
					if (p._preview == null) p._preview = PLYEditorUtil.GetAssetPreview(p.gameObject);
					if (isAutoTile)
					{
						if (PLYEditorUtil.ActiveButton(r, p._preview, p.name, (autoTilesSelection && ed_selectedSet == setId && ed_selectedTile == tileId && ed_selectedType == tileType), UniRPGEditorBase.IconToggleButtonOffStyle, UniRPGEditorBase.IconToggleButtonOnStyle))
						{
							autoTilesSelection = true;
							ed_selectedSet = setId;
							ed_selectedTile = tileId;
							ed_selectedType = tileType;
							SpawnCurrObj(p.gameObject);
							PLYEditorUtil.FocusSceneView();
						}
					}
					else
					{
						if (PLYEditorUtil.ActiveButton(r, p._preview, p.name, (!autoTilesSelection && ed_selectedSet == setId && ed_selectedTile == tileId), UniRPGEditorBase.IconToggleButtonOffStyle, UniRPGEditorBase.IconToggleButtonOnStyle))
						{
							autoTilesSelection = false;
							ed_selectedSet = setId;
							ed_selectedTile = tileId;
							ed_selectedType = TilePiece.Kind.None;
							SpawnCurrObj(p.gameObject);
							PLYEditorUtil.FocusSceneView();
						}
					}

					column++; r.x += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.right;
					if (column >= columns) { column = 0; r.x = startX; r.y += 64 + UniRPGEditorBase.IconToggleButtonOffStyle.margin.bottom; }
				}
			}
			return r;
		}

		#endregion
		// ================================================================================================================
		#region Scene GUI

		public void OnSceneGUI()
		{
			if (editModeOn)
			{
				// force the "view" mode
				Tools.current = Tool.View;
			}
			if (editModeOn && EditorWindow.mouseOverWindow!=null)
			{
				// draw scene view related gui and handles
				OnSceneGUI_Editor();
				OnSceneGUI_Info();
			}

			if (forceGuiDirty)
			{	// repaint the Inspector now
				forceGuiDirty = false;
				this.Repaint();
			}
		}

		private void OnSceneGUI_Info()
		{
			if (Event.current.type == EventType.KeyUp)
			{
				if (Event.current.control)
				{
					if (Target.kind == UniRPG.MapKind.Terrain)
					{	// change height
						if (Event.current.keyCode == KeyCode.UpArrow) { Target.ed_currentLevel++; forceGuiDirty = true; Event.current.Use(); }
						if (Event.current.keyCode == KeyCode.DownArrow) { Target.ed_currentLevel--; forceGuiDirty = true; Event.current.Use(); }
					}

					if (selectedTool != ToolTypes.AutoTiles)
					{	// rotate active tile/plop
						if (Event.current.keyCode == KeyCode.LeftArrow) { ChangeDirection(false, (selectedTool==ToolTypes.Plops), true); forceGuiDirty = true; Event.current.Use(); }
						if (Event.current.keyCode == KeyCode.RightArrow) { ChangeDirection(true, (selectedTool == ToolTypes.Plops), true); forceGuiDirty = true; Event.current.Use(); }
					}
				}

				if (Target.kind == UniRPG.MapKind.Terrain && selectedTool == ToolTypes.AutoTiles)
				{	// toggle molding mode
					if (Event.current.keyCode == KeyCode.Tab) { moldingMode = !moldingMode; forceGuiDirty = true; Event.current.Use(); }
				}

				if (selectedTool == ToolTypes.Tiles)
				{	// toggle replace mode
					if (Event.current.keyCode == KeyCode.Tab) { tileReplaceMode = !tileReplaceMode; forceGuiDirty = true; Event.current.Use(); }
				}

				if (editModeOn)
				{
					if (Event.current.keyCode == KeyCode.Delete && selectedTool == ToolTypes.Plops)
					{	// delete the selected plop
						forceGuiDirty = true; Event.current.Use();
						if (currObj != null) DestroyImmediate(currObj);
						ed_selectedPlop = -1; ed_selectedPlopSet = -1;
					}

					if (Event.current.keyCode == KeyCode.Escape)
					{
						editModeOn = false; forceGuiDirty = true; Event.current.Use();
						if (currObj != null) DestroyImmediate(currObj);
					}
				}

			}

			//Handles.BeginGUI(); GUILayout.BeginArea(new Rect(0,0,200,300), PLYEditorUtil.BoxStyle);
			//{
			//    GUILayout.Label("Will put some info here");
			//}
			//GUILayout.EndArea(); Handles.EndGUI();
		}

		private void OnSceneGUI_Editor()
		{
			// find mouse position on grid
			Vector3 pos = Target.transform.position; pos.y += (Target.ed_currentLevel * Target.tileHeight);
			float dist = 0f;
			Ray ray = HandleUtility.GUIPointToWorldRay(Event.current.mousePosition);
			Plane rayPlane = new Plane(new Vector3(0f, 1f, 0f), pos);
			if (rayPlane.Raycast(ray, out dist))
			{
				pos = ray.GetPoint(dist);

				gridOffset = Target.transform.position;
				gridOffset.x -= Target.tileSize / 2f;
				gridOffset.z -= Target.tileSize / 2f;

				// only bother to continue if the mouse is over the grid
				if (pos.x - gridOffset.x >= 0 && pos.z - gridOffset.z >= 0 && pos.x - gridOffset.x < Target.width * Target.tileSize && pos.z - gridOffset.z < Target.length * Target.tileSize)
				{
					onTheGrid = true;
					Color currcol = (Event.current.button == 1 ? Cursor3D_DelCol : Cursor3D_PlaceCol);

					if (Event.current.button != 1)
					{
						if (selectedTool == ToolTypes.Select)
						{
							currcol = Color.white;
							currcol.a = 0.1f;
						}
						else if (autoTilesSelection || selectedTool == ToolTypes.AutoTiles)
						{
							if (ed_selectedSet < Target.db.autoTiles.Count && ed_selectedSet >= 0 && ed_selectedTile >= 0)
							{
								if (Target.db.autoTiles[ed_selectedSet] != null)
								{
									currcol = Target.db.autoTiles[ed_selectedSet].editorColor;
									currcol.a = (currObj != null ? 0.1f : 0.5f);
								}
							}
						}
						else
						{
							if (ed_selectedSet < Target.db.tiles.Count && ed_selectedSet >= 0 && ed_selectedTile >= 0)
							{
								if (Target.db.tiles[ed_selectedSet] != null)
								{
									currcol = Target.db.tiles[ed_selectedSet].editorColor;
									currcol.a = (currObj != null ? 0.1f : 0.5f);
								}
							}
						}
					}

					// calc pos for plops
					if (selectedTool == ToolTypes.Plops)
					{
						// ...
						if (plopToTileHeight)
						{
							// find out which tile the plop is over
							cursorPos = new Vector3(Mathf.Floor((pos.x * Target.tileSize) - gridOffset.x), pos.y - gridOffset.y, Mathf.Floor((pos.z * Target.tileSize) - gridOffset.z));
							int y = (int)(cursorPos.z / Target.tileSize);
							int x = (int)(cursorPos.x / Target.tileSize);
							int idx = y * Target.width + x;
							if (idx >= 0 && idx < Target.tiles.Length)
							{
								if (Target.tiles[idx] != null)
								{
									pos.y = Target.tiles[idx].transform.position.y;
								}
							}
						}

						// ...
						if (plopSnapping == 0)
						{
							cursorPos = pos - Target.transform.position;
						}
						else
						{
							Vector3 offs = new Vector3(-Target.tileSize / 2f, 0f, -Target.tileSize / 2f);

							float s = Target.tileSize / (float)plopSnapping;
							pos.x -= offs.x / (float)plopSnapping;
							pos.z -= offs.z / (float)plopSnapping;
							cursorPos = new Vector3
							(
								s * (int)(pos.x / (float)s),
								pos.y,
								s * (int)(pos.z / (float)s)
							);
							cursorPos -= Target.transform.position;

							//float s = Target.tileSize / (float)plopSnapping;
							//pos.x -= gridOffset.x / (float)plopSnapping;
							//pos.y -= gridOffset.y;
							//pos.z -= gridOffset.z / (float)plopSnapping;
							//cursorPos = new Vector3
							//(
							//	s * (int)(pos.x / (float)s),
							//	pos.y,
							//	s * (int)(pos.z / (float)s)
							//);
						}

						// ...
						if (plopSnapColliders)
						{	// adjust height of plop so it does not stick through plop below it
							Vector3 start = cursorPos; start.y += (Target.tileHeight * 20f);
							RaycastHit[] hits = Physics.RaycastAll(start, -Vector3.up, (Target.tileHeight * 20f));
							if (hits.Length > 0)
							{
								for (int i=0; i<hits.Length; i++)
								{
									if (null != hits[i].collider.gameObject.GetComponent<TilePiece>()) continue;
									if ((plopColMask & (1 << hits[i].transform.gameObject.layer)) != 0)
									{
										if (cursorPos.y < hits[i].point.y) cursorPos.y = hits[i].point.y;
									}
								}
							}
						}
					}

					// calc pos for tiles
					else
					{
						pos.x -= gridOffset.x;
						pos.y -= gridOffset.y;
						pos.z -= gridOffset.z;
						cursorPos = new Vector3
						(
							Target.tileSize * (int)(pos.x / (float)Target.tileSize),
							pos.y,
							Target.tileSize * (int)(pos.z / (float)Target.tileSize)
						);

						if (!Event.current.alt && selectedTool != ToolTypes.Paste)
						{
							if (brushSize > 1) PLYEditorUtil.SceneDrawRects(brushSize, cursorPos + Target.transform.position, Target.tileSize, Target.tileSize, currcol, Cursor3D_Color);
							else PLYEditorUtil.SceneDrawRect(cursorPos + Target.transform.position, Target.tileSize, Target.tileSize, currcol, Cursor3D_Color);
							HandleUtility.Repaint();
						}
					}

					if (currObj != null)
					{
						if (selectedTool == ToolTypes.AutoTiles)
						{	// dont show the object in auto-tile mode
							DestroyImmediate(currObj);
						}
						else
						{
#if UNITY_3
							if (!currObj.active)
							{
								if (Event.current.button != 1 && !Event.current.alt) currObj.SetActiveRecursively(true);
							}
							else
							{	// hide the object if right-mouse held, which is for deleting tiles
								if (Event.current.button == 1 || Event.current.alt) currObj.SetActiveRecursively(false);
							}
#else
							if (!currObj.activeSelf)
							{
								if (Event.current.button != 1 && !Event.current.alt) currObj.SetActive(true);
							}
							else
							{	// hide the object if right-mouse held, which is for deleting tiles
								if (Event.current.button == 1 || Event.current.alt) currObj.SetActive(false);
							}

#endif
							currObj.transform.position = cursorPos + PreviewObjectOffset + Target.transform.position;
							if (Target.kind == UniRPG.MapKind.Dungeon && selectedTool == ToolTypes.Tiles && ed_selectedSet < Target.db.autoTiles.Count && autoTilesSelection)
							{
								if (Target.db.autoTiles[ed_selectedSet].isLower) currObj.transform.position -= new Vector3(0f, Target.tileHeight, 0f);
							}
						}
					}
					else if (selectedTool == ToolTypes.Tiles && !Event.current.alt)
					{	// only auto-spawm preview object for tiles tool
						CheckCurrObj();
					}
					
				}
				else
				{
					onTheGrid = false;
#if UNITY_3
					if (currObj != null) currObj.SetActiveRecursively(false);
#else
					if (currObj != null) currObj.SetActive(false);
#endif
				}
			}

			// show selected tiles
			if (selectedTool == ToolTypes.Select)
			{
				if (selectBuffer.Count > 0)
				{
					foreach (int idx in selectBuffer)
					{
						float z = (idx / Target.width);
						float x = (idx - (z * Target.width));
						Vector3 cpos = new Vector3
						(
							Target.tileSize * x,
							0f,
							Target.tileSize * z
						);

						PLYEditorUtil.SceneDrawRect(cpos + Target.transform.position, Target.tileSize, Target.tileSize, SelectionColour, Cursor3D_Color);
					}
					HandleUtility.Repaint();
				}
			}

			// show tiles for pasting
			if (selectedTool == ToolTypes.Paste)
			{
				if (copyBuffer.Count > 0)
				{
					foreach (CopyData d in copyBuffer)
					{
						Vector3 cpos = new Vector3(Target.tileSize * d.x, 0f, Target.tileSize * d.y);
						PLYEditorUtil.SceneDrawRect(cursorPos + cpos + Target.transform.position, Target.tileSize, Target.tileSize, PasteColour, Cursor3D_Color);
					}
					HandleUtility.Repaint();
				}
			}

			// handle input
			if (Event.current.type == EventType.mouseDown && (Event.current.button == 0 || Event.current.button == 1))
			{
				if (onTheGrid && !Event.current.alt && !Event.current.control && (Event.current.button == 0 || Event.current.button == 1))
				{
					dragOnGrid = true;
					int y = (int)(cursorPos.z / Target.tileSize);
					int x = (int)(cursorPos.x / Target.tileSize);

					switch (selectedTool)
					{
						case ToolTypes.Paste:
						{
							PasteTiles(x, y);
						} break;

						case ToolTypes.Select:
						{
							prevMarkX = x; prevMarkY = y;
							MarkTiles(x, y);
						} break;

						case ToolTypes.AutoTiles:
						{
							currentPlacementHeight = Target.ed_currentLevel;
							if (moldingMode && Target.kind == UniRPG.MapKind.Terrain)
							{	// check if clicked on existing tile and adapt to its height
								int idx = y * Target.width + x;

								if (Target.tiles[idx] != null)
								{
									TilePiece piece = Target.tiles[idx].GetComponent<TilePiece>();
									//if (piece.type == TilePiece.Type.Floor)
									//{
										if (Event.current.button == 0)
										{
											if (piece.floorLevel < Target.ed_currentLevel) currentPlacementHeight = piece.floorLevel + 1;
											else currentPlacementHeight = Target.ed_currentLevel + 1;
										}
										else if (Event.current.button == 1)
										{
											if (piece.floorLevel > Target.ed_currentLevel) currentPlacementHeight = piece.floorLevel - 1;
											else currentPlacementHeight = Target.ed_currentLevel - 1;
										}
									//}
								}
							}
							if (Target.kind == UniRPG.MapKind.Dungeon) PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0));
							else PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0 || moldingMode));
						} break;

						case ToolTypes.Tiles:
						{
							PlaceTile(x, y, Event.current.button == 0);
						} break;

						case ToolTypes.Plops:
						{
							PlacePlop();
						} break;
					}

				}
			}

			if (Event.current.type == EventType.dragPerform || Event.current.type == EventType.DragExited ||
				Event.current.type == EventType.dragUpdated || Event.current.type == EventType.mouseDrag)
			{
				if (dragOnGrid && !Event.current.alt && !Event.current.control && (Event.current.button == 0 || Event.current.button == 1))
				{
					int y = (int)(cursorPos.z / Target.tileSize);
					int x = (int)(cursorPos.x / Target.tileSize);

					switch (selectedTool)
					{
						case ToolTypes.Select:
						{
							if (prevMarkX!=x || prevMarkY!=y)
							{
								prevMarkX = x; prevMarkY = y;
								MarkTiles(x, y);
							}

						} break;

						case ToolTypes.AutoTiles:
						{
							if (Target.kind == UniRPG.MapKind.Dungeon) PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0));
							else PlaceAutoTile(x, y, currentPlacementHeight, (Event.current.button == 0 || moldingMode));
						} break;

						case ToolTypes.Tiles:
						{
							PlaceTile(x, y, Event.current.button == 0);
						} break;

					}

					Event.current.Use(); // so that mouse drags dont move/rotate view in Tool.View mode
				}
				else dragOnGrid = false;
			}

			if (Event.current.type == EventType.mouseUp || Event.current.type == EventType.ignore)
			{
				dragOnGrid = false;
				prevMarkX = 0; prevMarkY = 0;
			}

			if (Event.current.type == EventType.scrollWheel && Event.current.control)
			{
				if (Event.current.delta.y < 0f) { forceGuiDirty = true; Target.ed_currentLevel++; Event.current.Use(); }
				if (Event.current.delta.y > 0f) { forceGuiDirty = true; Target.ed_currentLevel--; Event.current.Use(); }
			}

		}

		private void PasteTiles(int x, int y)
		{
			foreach (CopyData d in copyBuffer)
			{
				int xx = x + d.x;
				int yy = y + d.y;
				if (xx < 0 || yy < 0 || xx >= Target.width || yy >= Target.length) continue;

				if (d.kind == TilePiece.Kind.None)
				{
					MapUtil.RemoveTile(Target, xx, yy);
				}
				else
				{
					// check if lower floor in auto set in which case I need to change floorLevel to take into account what the tile spawning code will do to it
					int level = d.floorLevel;
					if (d.fromAutoTileSet)
					{
						if (Target.db.autoTiles[d.setIdx].isLower) level++;
					}

					MapUtil.PlaceTile(Target, xx, yy, level, d.setIdx, d.tileIdx, true, d.faceDir, 1, d.fromAutoTileSet, d.kind);

					foreach (CopyData d2 in d.linkedPieces)
					{
						if (d2.kind == TilePiece.Kind.None) continue;

						// check if lower floor in auto set in which case I need to change floorLevel to take into account what the tile spawning code will do to it
						level = d2.floorLevel;
						if (d2.fromAutoTileSet)
						{
							if (Target.db.autoTiles[d2.setIdx].isLower) level++;
						}

						MapUtil.PlaceTile(Target, xx, yy, level, d2.setIdx, d2.tileIdx, false, d2.faceDir, 1, d2.fromAutoTileSet, d2.kind);
					}

					HideWireframeFor(Target, xx, yy);
				}
			}
		}

		private void MarkTiles(int x, int y)
		{
			if (brushSize == 1)
			{
				int idx = y * Target.width + x;
				if (selectBuffer.Contains(idx)) selectBuffer.Remove(idx);
				else selectBuffer.Add(idx);
			}
			else
			{
				int bs = (brushSize / 2);
				int sx = x - bs;
				int sy = y - bs;
				int ex = x + (brushSize - bs);
				int ey = y + (brushSize - bs);
				for (int xx = sx; xx < ex; xx++)
					for (int yy = sy; yy < ey; yy++)
					{
						if (xx < 0 || yy < 0 || xx >= Target.width || yy >= Target.length) continue;
						int idx = yy * Target.width + xx;
						if (selectBuffer.Contains(idx)) selectBuffer.Remove(idx);
						else selectBuffer.Add(idx);
					}
			}
		}

		private void PlaceTile(int x, int y, bool place)
		{
			if (place)
			{
				if (Application.isEditor)
				{
					MapUtil.PlaceTile(Target, x, y, Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, tileReplaceMode, currDir, brushSize, autoTilesSelection, ed_selectedType);
				}
				else
				{
					Target.PlaceTile(x, y, Target.ed_currentLevel, ed_selectedSet, ed_selectedTile, tileReplaceMode, currDir, brushSize, autoTilesSelection, ed_selectedType);
				}

				if (brushSize == 1) HideWireframeFor(Target, x, y);
				else
				{
					int bs = (brushSize / 2);
					int sx = x - bs;
					int sy = y - bs;
					int ex = x + (brushSize - bs);
					int ey = y + (brushSize - bs);
					for (int xx = sx; xx < ex; xx++) for (int yy = sy; yy < ey; yy++) HideWireframeFor(Target, xx, yy);					
				}
			}
			else
			{
				if (Application.isEditor) MapUtil.RemoveTile(Target, x, y, brushSize);
				else Target.RemoveTile(x, y, brushSize);
			}
		}

		private void PlaceAutoTile(int x, int y, int height, bool place)
		{
			if (Application.isEditor)
			{
				if (place) MapUtil.PlaceAutoTile(Target, x, y, height, ed_selectedSet, ed_selectedTile, brushSize, tileReplaceMode, floorRandomRot, floorRandomTile);
				else MapUtil.RemoveAutoTile(Target, x, y, brushSize, ed_selectedSet);
			}
			else
			{
				if (place) Target.PlaceAutoTile(x, y, height, ed_selectedSet, ed_selectedTile, brushSize, tileReplaceMode, floorRandomRot, floorRandomTile);
				else Target.RemoveAutoTile(x, y, brushSize, ed_selectedSet);
			}

			if (Target.kind == UniRPG.MapKind.Dungeon || place)
			{
				if (brushSize == 1)
				{
					HideWireframeFor(Target, x, y);
					HideWireframeFor(Target, x, y - 1);
					HideWireframeFor(Target, x, y + 1);
					HideWireframeFor(Target, x - 1, y);
					HideWireframeFor(Target, x - 1, y - 1);
					HideWireframeFor(Target, x - 1, y + 1);
					HideWireframeFor(Target, x + 1, y);
					HideWireframeFor(Target, x + 1, y - 1);
					HideWireframeFor(Target, x + 1, y + 1);
				}

				else
				{
					int bs = (brushSize / 2);
					int sx = x - bs - 2;
					int sy = y - bs - 2;
					int ex = x + (brushSize - bs) + 2;
					int ey = y + (brushSize - bs) + 2;

					for (int xx = sx; xx < ex; xx++)
					{
						for (int yy = sy; yy < ey; yy++)
						{
							HideWireframeFor(Target, xx, yy);
						}
					}
				}
			}

		}

		private void PlacePlop()
		{
			if (Event.current.button != 0) return;
			if (ed_selectedPlopSet == -1 || ed_selectedPlop == -1) return;

			if (Application.isEditor)
			{
				GameObject go = MapUtil.PlacePlop(Target, cursorPos, currDir, ed_selectedPlopSet, ed_selectedPlop);
				if (go && Target.hideWireframes) PLYEditorUtil.HideRendererWireframe(go, true);
			}
			else
			{
				GameObject go = Target.PlacePlop(cursorPos, currDir, ed_selectedPlopSet, ed_selectedPlop);
				if (go && Target.hideWireframes) PLYEditorUtil.HideRendererWireframe(go, true);
			}
		}

		public static void HideWireframeFor(Map map, int x, int y)
		{
			if (x < 0 || y < 0 || x >= map.width || y >= map.length) return;
			int idx = y * map.width + x;
			GameObject go = map.tiles[idx];
			if (go != null && map.hideWireframes)
			{
				PLYEditorUtil.HideRendererWireframe(go, true);
				TilePiece piece = map.tiles[idx].GetComponent<TilePiece>();
				if (piece.linkedPieces != null)
				{
					foreach (GameObject g in piece.linkedPieces) PLYEditorUtil.HideRendererWireframe(g, true);
				}
			}
		}

		public static void HideWireframeFor(Map map, bool hide)
		{
			foreach (GameObject go in map.tiles)
			{
				if (go != null)
				{
					PLYEditorUtil.HideRendererWireframe(go, hide);
					TilePiece piece = go.GetComponent<TilePiece>();
					if (piece.linkedPieces != null)
					{
						foreach (GameObject g in piece.linkedPieces) PLYEditorUtil.HideRendererWireframe(g, hide);
					}
				}
			}
		}

		#endregion
		// ================================================================================================================
	}
}