﻿// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections.Generic;

namespace UniRPGRuntime
{
	[System.Serializable]
	public class DefPlopSet
	{
		public string name = "PlopSet";						// name of this set
		public Color editorColor = Color.cyan;				// colour used in editor
		public UniRPG.PlopKind kind = UniRPG.PlopKind.Prop;	// the kind of ploppable

		// the maps this tile-set is allowed on
		public UniRPG.MapKind allowedMapsMask = (UniRPG.MapKind.Dungeon | UniRPG.MapKind.Terrain);

		// the ploppables in this set
		public List<GameObject> plops = new List<GameObject>();

		// ================================================================================================================
	}
}
