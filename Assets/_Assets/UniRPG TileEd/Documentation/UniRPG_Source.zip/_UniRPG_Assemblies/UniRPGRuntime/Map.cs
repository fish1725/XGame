// ====================================================================================================================
// -== UniRPG ==-
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using PLYCommon;

namespace UniRPGRuntime
{
	public class Map : MonoBehaviour
	{
		// ================================================================================================================
		#region Inspector and Properties

		public UniRPG.MapKind kind = UniRPG.MapKind.Terrain;	// the kind of map
		public int width = 32;									// size of the grid
		public int length = 32;
		public float tileSize = 1f;								// the size of each tile (width x length)
		public float tileHeight = 1f;							// the height of a tile

		// the prefabs container (contains the tiles prefabs, et)
		public PrefabDB db;

		// the tiles in this map
		public GameObject[] tiles = new GameObject[32 * 32];

		// the main container for all plops
		public Transform plopsContainer;

		#endregion
		// ================================================================================================================
		#region Tools to Create and Setup maps

		public static Map CreateNewMap(string name, UniRPG.MapKind kind, int w, int l, float tileSize, float tileHeight, PrefabDB db)
		{
			if (string.IsNullOrEmpty(name) || w <= 0 || l <= 0 || tileSize <= 0.1f || db == null) return null;

			GameObject go = new GameObject();
			Map map = go.AddComponent<Map>();
			map.name = name;
			map.kind = kind;
			map.width = w;
			map.length = l;
			map.tileSize = tileSize;
			map.tileHeight = tileHeight;
			map.db = db;
			map.tiles = new GameObject[map.width * map.length];

			map.ed_currentLevel = 0;

			return map;
		}

		public void RemoveAllTiles()
		{
			for (int i = 0; i < tiles.Length; i++)
			{
				if (tiles[i] != null) DestroyTile(i);
			}
		}

		private void DestroyTile(int idx)
		{
			// first delete any linked pieces
			TilePiece piece = tiles[idx].GetComponent<TilePiece>();
			if (piece.linkedPieces != null)
			{
				foreach (GameObject go in piece.linkedPieces) PLYUtil.DestroyObject(go);
				piece.linkedPieces.Clear();
			}

			// now delete main piece and remove from tiles array
			PLYUtil.DestroyObject(tiles[idx]);
			tiles[idx] = null;
		}

		private void DestroyLinkedPiecesIn(TilePiece mainPiece)
		{
			if (mainPiece.linkedPieces != null)
			{
				foreach (GameObject go in mainPiece.linkedPieces) PLYUtil.DestroyObject(go);
				mainPiece.linkedPieces.Clear();
			}
		}

		private void DestroyLinkedPiecesOfFromSetIn(TilePiece mainPiece, int setIdx)
		{
			if (mainPiece.linkedPieces != null)
			{
				List<GameObject> remove = new List<GameObject>();
				foreach (GameObject go in mainPiece.linkedPieces)
				{
					TilePiece p = go.GetComponent<TilePiece>();
					if (p.setIdx == setIdx) remove.Add(go);
				}
				foreach (GameObject go in remove)
				{
					mainPiece.linkedPieces.Remove(go);
					PLYUtil.DestroyObject(go);
				}
				remove.Clear();
			}
		}

		#endregion
		// ================================================================================================================
		#region Tiles Specific (manually placed tiles from normal sets and auto-tile sets)

		public void RemoveTile(int x, int y, int brushSize=1)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return;
			int idx = 0;
			if (brushSize == 1)
			{
				idx = y * width + x;
				if (tiles[idx] != null) DestroyTile(idx);
			}
			else
			{
				int bs = (brushSize / 2);
				int sx = x - bs;
				int sy = y - bs;
				int ex = x + (brushSize - bs);
				int ey = y + (brushSize - bs);

				for (int xx = sx; xx < ex; xx++)
					for (int yy = sy; yy < ey; yy++)
					{
						if (xx < 0 || yy < 0 || xx >= width || yy >= length) continue;
						idx = yy * width + xx;
						if (tiles[idx] != null) DestroyTile(idx);
					}
			}
		}

		public void FloodFillTile(int floorLevel, int setIdx, int tileIdx, TilePiece.Direction faceDirection = TilePiece.Direction.Up)
		{
			if (setIdx < 0 || setIdx >= db.tiles.Count) return;
			if (tileIdx < 0 || tileIdx >= db.tiles[setIdx].tiles.Count) return;

			RemoveAllTiles();
			bool failed = false;

			for (int x = 0; x < this.width; x++)
			{
				for (int y = 0; y < this.length; y++)
				{
					if (null == SpawnTilePiece(null, x, y, setIdx, tileIdx, floorLevel, faceDirection))
					{	// early out of the loops if it failed to spawn
						failed = true; break;
					}
				}
				if (failed) break;
			}
		}

		public void PlaceTile(int x, int y, int floorLevel, int setIdx, int tileIdx, bool replaceExisting = true, TilePiece.Direction faceDirection = TilePiece.Direction.Up, int brushSize = 1, bool fromAutoTiles = false, TilePiece.Kind pieceType = TilePiece.Kind.None)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return;
			if (setIdx < 0 || tileIdx < 0) return;
			if (faceDirection == TilePiece.Direction.Invalid) faceDirection = TilePiece.Direction.Up;

			if (db.autoTiles[setIdx].isLower) floorLevel--;
			//if (this.kind == Map.Kind.World) floorLevel = 0;

			// few more checks
			if (fromAutoTiles)
			{
				if (setIdx >= db.autoTiles.Count) return;
				if (tileIdx >= db.autoTiles[setIdx].tiles.Count) return;
				if (pieceType == TilePiece.Kind.None) return;
				if (db.autoTiles[setIdx].tiles[tileIdx].pieces[(int)pieceType] == null) return;
			}
			else
			{
				if (setIdx >= db.tiles.Count) return;
				if (db.tiles[setIdx].tiles[tileIdx] == null) return;
			}

			// now spawn
			if (brushSize == 1)
			{
				// first destroy the tile in the way
				int idx = y * width + x;
				TilePiece mainPiece = null;
				if (tiles[idx] != null)
				{
					if (replaceExisting) DestroyTile(idx);
					else mainPiece = tiles[idx].GetComponent<TilePiece>();
				}

				if (fromAutoTiles) SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, pieceType, faceDirection);
				else SpawnTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, faceDirection);
			}
			else
			{
				int bs = (brushSize / 2);
				int sx = x - bs;
				int sy = y - bs;
				int ex = x + (brushSize - bs);
				int ey = y + (brushSize - bs);
				for (int xx = sx; xx < ex; xx++)
					for (int yy = sy; yy < ey; yy++)
					{
						if (xx < 0 || yy < 0 || xx >= width || yy >= length) continue;
						int idx = yy * width + xx;
						TilePiece mainPiece = null;
						if (tiles[idx] != null)
						{
							if (replaceExisting) DestroyTile(idx);
							else mainPiece = tiles[idx].GetComponent<TilePiece>();
						}
						if (fromAutoTiles) SpawnAutoTilePiece(mainPiece, xx, yy, setIdx, tileIdx, floorLevel, pieceType, faceDirection);
						else SpawnTilePiece(mainPiece, xx, yy, setIdx, tileIdx, floorLevel, faceDirection);
					}
			}

		}

		private TilePiece SpawnTilePiece(TilePiece mainPiece, int x, int y, int setIdx, int tileIdx, int floorLevel, TilePiece.Direction faceDirection)
		{
			if (setIdx < 0 || setIdx >= db.tiles.Count) return null;
			if (tileIdx < 0 || tileIdx >= db.tiles[setIdx].tiles.Count) return null;

			// find what to spawn
			GameObject prefab = db.tiles[setIdx].tiles[tileIdx];
			if (prefab == null) return null;

			// spawn it
			GameObject go = GameObject.Instantiate(prefab) as GameObject;
			go.transform.position = new Vector3(x * tileSize, floorLevel * tileHeight, y * tileSize);
			go.transform.position += this.transform.position;

			//if (tilesParent == null)
			//{
			//    tilesParent = this.transform.FindChild("Tiles");
			//    if (tilesParent == null)
			//    {
			//        GameObject parentGo = new GameObject("Tiles");
			//        tilesParent = parentGo.transform;
			//        tilesParent.parent = this.transform;
			//        tilesParent.localPosition = Vector3.zero;
			//        tilesParent.localRotation = Quaternion.identity;
			//    }
			//}

			go.transform.parent = this.transform;

			Vector3 rot = go.transform.localRotation.eulerAngles;
			rot.y = (float)faceDirection;
			go.transform.localRotation = Quaternion.Euler(rot);

			int idx = y * width + x;
			go.name = idx.ToString() + "-" + prefab.name;

			TilePiece piece = go.GetComponent<TilePiece>();
			piece.kind = TilePiece.Kind.None;
			piece.setIdx = setIdx;
			piece.tileIdx = tileIdx;
			piece.floorLevel = floorLevel;
			piece.faceDir = faceDirection;
			piece.fromAutoTileSet = false;

			if (mainPiece != null)
			{
				// link the extra pieces to the "main" one
				if (mainPiece.linkedPieces == null) mainPiece.linkedPieces = new List<GameObject>();
				mainPiece.linkedPieces.Add(piece.gameObject);
			}
			else
			{
				tiles[idx] = piece.gameObject;
			}

			return piece;
		}

		#endregion
		// ================================================================================================================
		#region Auto-Tiles Specific

		// brushSize is ignored for Dungeon since it works only with 1 size brushes
		public void RemoveAutoTile(int x, int y, int brushSize=1, int selectedSet=-1)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return;

			int idx = y * width + x;
			if (brushSize == 1)
			{
				if (tiles[idx] != null)
				{
					TilePiece piece = tiles[idx].GetComponent<TilePiece>();
					if (this.kind == UniRPG.MapKind.Dungeon)
					{	// can only delete a floor tile, the system auto update walls and such
						if (piece.kind == TilePiece.Kind.Floor)
						{
							DestroyTile(idx);

							PreUpdateAutoTilePieces(x - 1, y);
							PreUpdateAutoTilePieces(x + 1, y);
							PreUpdateAutoTilePieces(x, y - 1);
							PreUpdateAutoTilePieces(x, y + 1);
							PreUpdateAutoTilePieces(x - 1, y - 1);
							PreUpdateAutoTilePieces(x + 1, y - 1);
							PreUpdateAutoTilePieces(x - 1, y + 1);
							PreUpdateAutoTilePieces(x + 1, y + 1);

							UpdateAutoTilePieces(x, y, null);
							UpdateAutoTilePieces(x - 1, y, null);
							UpdateAutoTilePieces(x + 1, y, null);
							UpdateAutoTilePieces(x, y - 1, null);
							UpdateAutoTilePieces(x, y + 1, null);
							UpdateAutoTilePieces(x - 1, y - 1, null);
							UpdateAutoTilePieces(x + 1, y - 1, null);
							UpdateAutoTilePieces(x - 1, y + 1, null);
							UpdateAutoTilePieces(x + 1, y + 1, null);
						}
						else
						{
							if (piece.fromAutoTileSet)
							{
								if (db.autoTiles[piece.setIdx].kind == UniRPG.TileSetKind.Expanding)
								{
									if (selectedSet >= 0)
									{	// if main piece is from selected set, then whipe whole thing
										if (piece.setIdx == selectedSet) DestroyTile(idx);
										// else, look for the selected set piece(s) and delete only those
										else DestroyLinkedPiecesOfFromSetIn(piece, selectedSet);
									}
									else DestroyTile(idx);
								}
							}
						}
					}
					else
					{
						if (selectedSet >= 0)
						{	// if main piece is from selected set, then whipe whole thing
							if (piece.setIdx == selectedSet) DestroyTile(idx);
							// else, look for the selected set piece(s) and delete only those
							else DestroyLinkedPiecesOfFromSetIn(piece, selectedSet); 
						}
						else DestroyTile(idx);
					}
				}
			}
			else
			{
				int bs = (brushSize / 2);
				int sx = x - bs;
				int sy = y - bs;
				int ex = x + (brushSize - bs);
				int ey = y + (brushSize - bs);

				for (int xx = sx; xx < ex; xx++)
				{
					for (int yy = sy; yy < ey; yy++)
					{
						if (xx < 0 || yy < 0 || xx >= width || yy >= length) continue;
						idx = yy * width + xx;
						if (tiles[idx] != null)
						{
							TilePiece piece = tiles[idx].GetComponent<TilePiece>();
							if (this.kind == UniRPG.MapKind.Dungeon)
							{
								if (piece.kind == TilePiece.Kind.Floor)
								{
									DestroyTile(idx);
									PreUpdateAutoTilePieces(xx - 1, yy);
									PreUpdateAutoTilePieces(xx + 1, yy);
									PreUpdateAutoTilePieces(xx, yy - 1);
									PreUpdateAutoTilePieces(xx, yy + 1);
									PreUpdateAutoTilePieces(xx - 1, yy - 1);
									PreUpdateAutoTilePieces(xx + 1, yy - 1);
									PreUpdateAutoTilePieces(xx - 1, yy + 1);
									PreUpdateAutoTilePieces(xx + 1, yy + 1);
									UpdateAutoTilePieces(xx, yy, null);
									UpdateAutoTilePieces(xx - 1, yy, null);
									UpdateAutoTilePieces(xx + 1, yy, null);
									UpdateAutoTilePieces(xx, yy - 1, null);
									UpdateAutoTilePieces(xx, yy + 1, null);
									UpdateAutoTilePieces(xx - 1, yy - 1, null);
									UpdateAutoTilePieces(xx + 1, yy - 1, null);
									UpdateAutoTilePieces(xx - 1, yy + 1, null);
									UpdateAutoTilePieces(xx + 1, yy + 1, null);
								}
							}
							else
							{
								if (selectedSet >= 0)
								{	// if main piece is from selected set, then whipe whole thing
									if (piece.setIdx == selectedSet) DestroyTile(idx);
									// else, look for the selected set piece(s) and delete only those
									else DestroyLinkedPiecesOfFromSetIn(piece, selectedSet);
								}
								else DestroyTile(idx);
							}
						}
					}
				}
			}

		}

		public void FloodFillAutoTile(int floorLevel, int setIdx, int tileIdx, TilePiece.Kind withType = TilePiece.Kind.Floor, TilePiece.Direction faceDirection = TilePiece.Direction.Up)
		{
			if (setIdx < 0 || setIdx >= db.autoTiles.Count) return;
			if (tileIdx < 0 || tileIdx >= db.autoTiles[setIdx].tiles.Count) return;
			if (withType == TilePiece.Kind.None) withType = TilePiece.Kind.Floor;

			RemoveAllTiles();
			bool failed = false;

			for (int x = 0; x < this.width; x++)
			{
				for (int y = 0; y < this.length; y++)
				{
					if (null == SpawnAutoTilePiece(null, x, y, setIdx, tileIdx, floorLevel, withType, faceDirection))
					{	// early out of the loops if it failed to spawn
						failed = true; break;
					}
				}
				if (failed) break;
			}
		}

		// brushSize is ignored for Dungeon since it works only with 1 size brushes
		// replaceCurrTile is ignored for everything except expanding-tiles (and will replace existing expanding tile in same set, if needed)
		public void PlaceAutoTile(int x, int y, int floorLevel, int setIdx, int tileIdx, int brushSize = 1, bool replaceCurrTile = false, bool floorRandomRot = false, bool floorRandomTile = false)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return;					// eish, not even on the map area?
			if (setIdx == -1 || setIdx >= db.autoTiles.Count) return;					// prevent index errors
			if (tileIdx == -1 || tileIdx >= db.autoTiles[setIdx].tiles.Count) return;	// prevent index errors

			if (db.autoTiles[setIdx].kind == UniRPG.TileSetKind.Expanding)
			{
				// a different function will handle expanding tiles
				PlaceExpandingTile(x, y, floorLevel, setIdx, tileIdx, brushSize, replaceCurrTile);
				return;
			}

			// the code to follow can only handle these tile kinds
			if (db.autoTiles[setIdx].kind != UniRPG.TileSetKind.Dungeon && 
				db.autoTiles[setIdx].kind != UniRPG.TileSetKind.Terrain) return;

			// cant use random rotation with 13-tile terrain system
			if (db.autoTiles[setIdx].kind == UniRPG.TileSetKind.Terrain && !db.autoTiles[setIdx].is_4_tile_system) floorRandomRot = false;

			if (db.autoTiles[setIdx].isLower) floorLevel--;

			TilePiece floorPiece = null;
			int idx = 0;
			int prevTileIdx = tileIdx;

			// place floor tile
			if (brushSize == 1)
			{
				if (floorRandomTile && db.autoTiles[setIdx].tiles.Count > 1)
				{	// choose a random floor tile piece from set
					tileIdx = Random.Range(0, db.autoTiles[setIdx].tiles.Count);
				}

				// check what kinda tile pieces are on same spot
				idx = y * width + x;
				if (tiles[idx] != null)
				{
					floorPiece = tiles[idx].GetComponent<TilePiece>();
					if (floorPiece.kind == TilePiece.Kind.Floor)
					{	// do not continue if the new floor tile is same style and on same level as current floor piece
						if (floorPiece.setIdx == setIdx && floorPiece.tileIdx == tileIdx && floorPiece.floorLevel == floorLevel) return;
					}

					// destroy current tile pieces
					DestroyTile(idx);
				}

				TilePiece.Direction dir = TilePiece.Direction.Up;
				if (floorRandomRot)
				{
					int r = Random.Range(0, 4);
					if (r == 1) dir = TilePiece.Direction.Right;
					else if (r == 2) dir = TilePiece.Direction.Down;
					else if (r == 3) dir = TilePiece.Direction.Left;
				}

				floorPiece = SpawnAutoTilePiece(null, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Floor, dir);
				if (floorPiece == null) return;

				// reset tileIdx if it was changed by random tile chooser so that painted walls are from user selected tileIdx
				prevTileIdx = tileIdx;

				// update walls and corners on and around the newly placed tile space
				if (this.kind == UniRPG.MapKind.Dungeon)
				{
					UpdateAutoTilePieces(x, y, floorPiece);
				}

				PreUpdateAutoTilePieces(x - 1, y);
				PreUpdateAutoTilePieces(x + 1, y);
				PreUpdateAutoTilePieces(x, y - 1);
				PreUpdateAutoTilePieces(x, y + 1);
				PreUpdateAutoTilePieces(x - 1, y - 1);
				PreUpdateAutoTilePieces(x + 1, y - 1);
				PreUpdateAutoTilePieces(x - 1, y + 1);
				PreUpdateAutoTilePieces(x + 1, y + 1);

				UpdateAutoTilePieces(x - 1, y, floorPiece);
				UpdateAutoTilePieces(x + 1, y, floorPiece);
				UpdateAutoTilePieces(x, y - 1, floorPiece);
				UpdateAutoTilePieces(x, y + 1, floorPiece);
				UpdateAutoTilePieces(x - 1, y - 1, floorPiece);
				UpdateAutoTilePieces(x + 1, y - 1, floorPiece);
				UpdateAutoTilePieces(x - 1, y + 1, floorPiece);
				UpdateAutoTilePieces(x + 1, y + 1, floorPiece);

				// terrain need a second pass
				if (this.kind == UniRPG.MapKind.Terrain)
				{
					UpdateAutoTilePieces(x - 1, y, floorPiece);
					UpdateAutoTilePieces(x + 1, y, floorPiece);
					UpdateAutoTilePieces(x, y - 1, floorPiece);
					UpdateAutoTilePieces(x, y + 1, floorPiece);
					UpdateAutoTilePieces(x - 1, y - 1, floorPiece);
					UpdateAutoTilePieces(x + 1, y - 1, floorPiece);
					UpdateAutoTilePieces(x - 1, y + 1, floorPiece);
					UpdateAutoTilePieces(x + 1, y + 1, floorPiece);
				}
			}

			// else, spawn a bunch of floors. brush bigger than 1
			else
			{
				int bs = (brushSize / 2);
				int sx = x - bs;
				int sy = y - bs;
				int ex = x + (brushSize - bs);
				int ey = y + (brushSize - bs);

				for (int xx = sx; xx < ex; xx++)
				{
					for (int yy = sy; yy < ey; yy++)
					{
						if (xx < 0 || yy < 0 || xx >= width || yy >= length) continue;

						if (floorRandomTile && db.autoTiles[setIdx].tiles.Count > 1)
						{	// choose a random floor tile piece from set
							tileIdx = Random.Range(0, db.autoTiles[setIdx].tiles.Count);
						}

						idx = yy * width + xx;
						if (tiles[idx] != null)
						{
							floorPiece = tiles[idx].GetComponent<TilePiece>();
							if (floorPiece.kind == TilePiece.Kind.Floor)
							{	// do not continue if the new floor tile is same style and on same level as current floor piece
								if (floorPiece.setIdx == setIdx && floorPiece.tileIdx == tileIdx && floorPiece.floorLevel == floorLevel) continue;
							}
							// destroy current tile pieces
							DestroyTile(idx);
						}

						TilePiece.Direction dir = TilePiece.Direction.Up;
						if (floorRandomRot)
						{
							int r = Random.Range(0, 4);
							if (r == 1) dir = TilePiece.Direction.Right;
							else if (r == 2) dir = TilePiece.Direction.Down;
							else if (r == 3) dir = TilePiece.Direction.Left;
						}
						floorPiece = SpawnAutoTilePiece(null, xx, yy, setIdx, tileIdx, floorLevel, TilePiece.Kind.Floor, dir);
						if (floorPiece == null) continue;
					}
				}

				// reset tileIdx if it was changed by random tile chooser so that painted walls are from user selected tileIdx
				prevTileIdx = tileIdx;

				// now update the tiles around the new floors 
				if (this.kind == UniRPG.MapKind.Dungeon)
				{	// for dungeon a check on the floor tile is needed too
					for (int xx = sx; xx < ex; xx++)
						for (int yy = sy; yy < ey; yy++)
						{
							UpdateAutoTilePieces(xx, yy, floorPiece);
						}
				}

				for (int xx = sx; xx < ex; xx++)
				{
					PreUpdateAutoTilePieces(xx, sy - 1);
					PreUpdateAutoTilePieces(xx, ey);
				}
				for (int yy = sy; yy < ey; yy++)
				{
					PreUpdateAutoTilePieces(sx - 1, yy);
					PreUpdateAutoTilePieces(ex, yy);
				}
				PreUpdateAutoTilePieces(sx - 1, sy - 1);
				PreUpdateAutoTilePieces(ex, sy - 1);
				PreUpdateAutoTilePieces(sx - 1, ey);
				PreUpdateAutoTilePieces(ex, ey);

				// update
				for (int xx = sx; xx < ex; xx++)
				{
					UpdateAutoTilePieces(xx, sy - 1, floorPiece);
					UpdateAutoTilePieces(xx, ey, floorPiece);
				}
				for (int yy = sy; yy < ey; yy++)
				{
					UpdateAutoTilePieces(sx - 1, yy, floorPiece);
					UpdateAutoTilePieces(ex, yy, floorPiece);
				}
				UpdateAutoTilePieces(sx - 1, sy - 1, floorPiece);
				UpdateAutoTilePieces(ex, sy - 1, floorPiece);
				UpdateAutoTilePieces(sx - 1, ey, floorPiece);
				UpdateAutoTilePieces(ex, ey, floorPiece);

			}
		}

		private void PlaceExpandingTile(int x, int y, int floorLevel, int setIdx, int tileIdx, int brushSize, bool replaceCurrTile)
		{
			TilePiece currPiece=null;
			int idx=0;
			if (brushSize == 1)
			{
				// check what kinda tile pieces are on same spot
				idx = y * width + x;
				if (tiles[idx] != null)
				{
					if (replaceCurrTile) this.DestroyTile(idx);
					else
					{
						currPiece = tiles[idx].GetComponent<TilePiece>();

						// no need to continue if exact same tile piece allready present
						//if (currPiece.setIdx == setIdx && currPiece.tileIdx == tileIdx && currPiece.floorLevel == floorLevel) return;

						// delete piece if it is same set but not same tile or height
						//if (currPiece.setIdx == setIdx && (currPiece.tileIdx != tileIdx || currPiece.floorLevel != floorLevel))
						if (currPiece.setIdx == setIdx)
						{
							this.DestroyTile(idx);
							currPiece = null;
						}

						// check other piees of the tile
						else if (currPiece.linkedPieces.Count > 0)
						{
							List<GameObject> remove = new List<GameObject>();
							foreach (GameObject po in currPiece.linkedPieces)
							{
								TilePiece p = po.GetComponent<TilePiece>();

								// no need to continue if exact same tile piece allready present
								//if (p.setIdx == setIdx && p.tileIdx == tileIdx && p.floorLevel == floorLevel) return;

								// delete piece if it is same set but not same tile or height
								//if (p.setIdx == setIdx && (p.tileIdx != tileIdx || p.floorLevel != floorLevel)) remove.Add(po);
								if (p.setIdx == setIdx) remove.Add(po);
							}
							foreach (GameObject r in remove)
							{
								currPiece.linkedPieces.Remove(r);
								PLYUtil.DestroyObject(r);
							}
							remove.Clear();
						}
					}
				}

				currPiece = Expanding_CalculateAndSpawn(currPiece, x, y, setIdx, tileIdx, floorLevel, false);
				if (currPiece == null) return;

				Expanding_CalculateAndSpawn(null, x + 1, y, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x - 1, y, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x, y + 1, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x, y - 1, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x + 1, y + 1, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x + 1, y - 1, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x - 1, y + 1, setIdx, tileIdx, floorLevel, true);
				Expanding_CalculateAndSpawn(null, x - 1, y - 1, setIdx, tileIdx, floorLevel, true);

			}
			else
			{
				int bs = (brushSize / 2);
				int sx = x - bs;
				int sy = y - bs;
				int ex = x + (brushSize - bs);
				int ey = y + (brushSize - bs);

				for (int xx = sx; xx < ex; xx++)
				{
					for (int yy = sy; yy < ey; yy++)
					{
						if (xx < 0 || yy < 0 || xx >= width || yy >= length) continue;

						// check what kinda tile pieces are on same spot
						currPiece = null;
						idx = yy * width + xx;
						if (tiles[idx] != null)
						{
							if (replaceCurrTile) this.DestroyTile(idx);
							else
							{
								currPiece = tiles[idx].GetComponent<TilePiece>();
								if (currPiece.setIdx == setIdx)
								{
									this.DestroyTile(idx);
									currPiece = null;
								}

								// check other pieces of the tile
								else if (currPiece.linkedPieces.Count > 0)
								{
									List<GameObject> remove = new List<GameObject>();
									foreach (GameObject po in currPiece.linkedPieces)
									{
										TilePiece p = po.GetComponent<TilePiece>();
										if (p.setIdx == setIdx) remove.Add(po);
									}
									foreach (GameObject r in remove)
									{
										currPiece.linkedPieces.Remove(r);
										PLYUtil.DestroyObject(r);
									}
									remove.Clear();
								}
							}
						}

						currPiece = Expanding_CalculateAndSpawn(currPiece, xx, yy, setIdx, tileIdx, floorLevel, false);
						if (currPiece == null) continue;

						Expanding_CalculateAndSpawn(null, xx + 1, yy, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx - 1, yy, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx, yy + 1, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx, yy - 1, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx + 1, yy + 1, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx + 1, yy - 1, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx - 1, yy + 1, setIdx, tileIdx, floorLevel, true);
						Expanding_CalculateAndSpawn(null, xx - 1, yy - 1, setIdx, tileIdx, floorLevel, true);
					}
				}
			}
		}

		private void PreUpdateAutoTilePieces(int x, int y)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return;
			int idx = y * width + x;
			if (tiles[idx] != null)
			{
				TilePiece p = tiles[idx].GetComponent<TilePiece>();

				// dont act on expanding tile
				if (db.autoTiles[p.setIdx].kind == UniRPG.TileSetKind.Expanding) return;

				// if floor, remove only linked pieces, else remove whole tile
				if (p.kind != TilePiece.Kind.Floor) DestroyTile(idx);
				else DestroyLinkedPiecesIn(p);
			}
		}

		private void UpdateAutoTilePieces(int x, int y, TilePiece placedFloor)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return;

			int idx = y * width + x;
			TilePiece mainPiece = null;
			if (tiles[idx] != null)
			{
				mainPiece = tiles[idx].GetComponent<TilePiece>();

				// dont act on expanding tile
				if (db.autoTiles[mainPiece.setIdx].kind == UniRPG.TileSetKind.Expanding) return;
			}

			switch (this.kind)
			{
				case UniRPG.MapKind.Dungeon:
				{
					List<CalculatedAutoSpawnInfo> spawnList = null;
					spawnList = Dungeon_CalculateAutoSpawnInfos(x, y);
					if (spawnList != null)
					{
						foreach (CalculatedAutoSpawnInfo nfo in spawnList)
						{
							TilePiece piece = SpawnAutoTilePiece(mainPiece, x, y, nfo.setIdx, nfo.tileIdx, nfo.floorLevel, nfo.type, nfo.faceDirection);
							if (mainPiece == null && piece != null) mainPiece = piece;
						}
					}
				} break;

				case UniRPG.MapKind.Terrain:
				{
					CalculatedAutoSpawnInfo nfo = Terrain_CalculateAutoSpawnInfos(x, y, placedFloor);
					if (nfo != null)
					{
						if (mainPiece != null) { DestroyTile(idx); mainPiece = null; }
						SpawnAutoTilePiece(mainPiece, x, y, nfo.setIdx, nfo.tileIdx, nfo.floorLevel, nfo.type, nfo.faceDirection);
					}
				}
				break;

			}
		}

		private TilePiece SpawnAutoTilePiece(TilePiece mainPiece, int x, int y, int setIdx, int tileIdx, int floorLevel, TilePiece.Kind type, TilePiece.Direction faceDirection)
		{
			if (setIdx < 0 || setIdx >= db.autoTiles.Count) return null;
			if (tileIdx < 0 || tileIdx >= db.autoTiles[setIdx].tiles.Count) return null;
			if (type == TilePiece.Kind.None) return null;

			// find what to spawn
			GameObject prefab = null;

			if (!db.autoTiles[setIdx].is_4_tile_system && db.autoTiles[setIdx].kind == UniRPG.TileSetKind.Terrain)
			{
				TilePiece.Kind type_helper = type;
				if (type == TilePiece.Kind.Wall)
				{
					switch (faceDirection)
					{
						case TilePiece.Direction.Up: type_helper = TilePiece.Kind.Wall; break;
						case TilePiece.Direction.Right: type_helper = TilePiece.Kind.Wall_2; break;
						case TilePiece.Direction.Down: type_helper = TilePiece.Kind.Wall_3; break;
						case TilePiece.Direction.Left: type_helper = TilePiece.Kind.Wall_4; break;
					}
				}
				else if (type == TilePiece.Kind.Corner1)
				{
					switch (faceDirection)
					{
						case TilePiece.Direction.Up: type_helper = TilePiece.Kind.Corner1_2; break;
						case TilePiece.Direction.Right: type_helper = TilePiece.Kind.Corner1_3; break;
						case TilePiece.Direction.Down: type_helper = TilePiece.Kind.Corner1_4; break;
						case TilePiece.Direction.Left: type_helper = TilePiece.Kind.Corner1; break;
					}
				}
				else if (type == TilePiece.Kind.Corner2)
				{
					switch (faceDirection)
					{
						case TilePiece.Direction.Up: type_helper = TilePiece.Kind.Corner2_2; break;
						case TilePiece.Direction.Right: type_helper = TilePiece.Kind.Corner2_3; break;
						case TilePiece.Direction.Down: type_helper = TilePiece.Kind.Corner2_4; break;
						case TilePiece.Direction.Left: type_helper = TilePiece.Kind.Corner2; break;
					}
				}
				
				prefab = db.autoTiles[setIdx].tiles[tileIdx].pieces[(int)type_helper];
				if (prefab == null && tileIdx > 0)
				{	// could not find the specified type for this tile, try a tile back since all tiles in a set should be working together
					for (int ti = tileIdx - 1; ti >= 0; ti--)
					{
						prefab = db.autoTiles[setIdx].tiles[ti].pieces[(int)type_helper];
						if (prefab != null) break;
					}
				}
			}

			else
			{
				prefab = db.autoTiles[setIdx].tiles[tileIdx].pieces[(int)type];
				if (prefab == null && tileIdx > 0)
				{	// could not find the specified type for this tile, try a tile back since all tiles in a set should be working together
					for (int ti = tileIdx - 1; ti >= 0; ti--)
					{
						prefab = db.autoTiles[setIdx].tiles[ti].pieces[(int)type];
						if (prefab != null) break;
					}
				}
			}

			if (prefab == null) return null;

			// spawn it		
			GameObject go = GameObject.Instantiate(prefab) as GameObject;
			go.transform.position = new Vector3(x * tileSize, floorLevel * tileHeight, y * tileSize);
			go.transform.position += this.transform.position;

			//if (tilesParent == null)
			//{
			//    tilesParent = this.transform.FindChild("Tiles");
			//    if (tilesParent == null)
			//    {
			//        GameObject parentGo = new GameObject("Tiles");
			//        tilesParent = parentGo.transform;
			//        tilesParent.parent = this.transform;
			//        tilesParent.localPosition = Vector3.zero;
			//        tilesParent.localRotation = Quaternion.identity;
			//    }
			//}

			go.transform.parent = this.transform;

			Vector3 rot = go.transform.localRotation.eulerAngles;
			rot.y = (float)faceDirection;
			go.transform.localRotation = Quaternion.Euler(rot);

			int idx = y * width + x;
			go.name = idx.ToString() + "-" + prefab.name;

			TilePiece piece = go.GetComponent<TilePiece>();
			piece.kind = type;
			piece.setIdx = setIdx;
			piece.tileIdx = tileIdx;
			piece.floorLevel = floorLevel;
			piece.faceDir = faceDirection;
			piece.fromAutoTileSet = true;

			if (mainPiece != null)
			{
				// link the extra pieces to the "main" one
				if (mainPiece.linkedPieces == null) mainPiece.linkedPieces = new List<GameObject>();
				mainPiece.linkedPieces.Add(piece.gameObject);
			}
			else
			{
				tiles[idx] = piece.gameObject;
			}

			return piece;
		}

		private class CalculatedAutoSpawnInfo
		{
			public TilePiece.Kind type;
			public TilePiece.Direction faceDirection;
			public int setIdx;
			public int tileIdx;
			public int floorLevel;
		}

		private TilePiece Expanding_CalculateAndSpawn(TilePiece mainPiece, int x, int y, int setIdx, int tileIdx, int floorLevel, bool isUpdate)
		{
			if (x < 0 || y < 0 || x >= width || y >= length) return null;

			// if is update, then only continue if there is a piece of kind, and remove existing
			if (isUpdate)
			{
				bool go_on = false;
				int idx = y * width + x;
				mainPiece = (tiles[idx] == null ? null : tiles[idx].GetComponent<TilePiece>());
				if (mainPiece != null)
				{
					if (mainPiece.setIdx == setIdx && mainPiece.floorLevel == floorLevel)
					{
						go_on = true;
						this.DestroyTile(idx);
						mainPiece = null;
					}

					else if (mainPiece.linkedPieces.Count > 0)
					{
						List<GameObject> remove = new List<GameObject>();
						foreach (GameObject go in mainPiece.linkedPieces)
						{
							TilePiece lp = go.GetComponent<TilePiece>();
							if (lp.setIdx == setIdx && lp.floorLevel == floorLevel)
							{
								go_on = true;
								remove.Add(go);
							}
						}
						foreach (GameObject r in remove)
						{
							mainPiece.linkedPieces.Remove(r);
							PLYUtil.DestroyObject(r);
						}
						remove.Clear();
					}
				}

				if (!go_on) return null;
			}

			// 6  3  7
			// 0  *  1
			// 4  2  5
			TilePiece[] t = { GetExpandingTileAt(x - 1, y, setIdx, floorLevel), GetExpandingTileAt(x + 1, y, setIdx, floorLevel), GetExpandingTileAt(x, y - 1, setIdx, floorLevel), GetExpandingTileAt(x, y + 1, setIdx, floorLevel), GetExpandingTileAt(x - 1, y - 1, setIdx, floorLevel), GetExpandingTileAt(x + 1, y - 1, setIdx, floorLevel), GetExpandingTileAt(x - 1, y + 1, setIdx, floorLevel), GetExpandingTileAt(x + 1, y + 1, setIdx, floorLevel) };
			TilePiece ret = null;

			// full 
			if (ret == null &&	t[0] != null && t[1] != null && t[2] != null && t[3] != null &&
								t[4] != null && t[5] != null && t[6] != null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Full, TilePiece.Direction.Up);

			// crossing 2
			if (ret == null && t[0] != null && t[1] != null && t[2] != null && t[3] != null)
			{
					 if (t[4] != null && t[5] == null && t[6] == null && t[7] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing3, TilePiece.Direction.Left);
				else if (t[4] == null && t[5] == null && t[6] != null && t[7] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing3, TilePiece.Direction.Up);
				else if (t[4] == null && t[5] == null && t[6] == null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing3, TilePiece.Direction.Right);
				else if (t[4] == null && t[5] != null && t[6] == null && t[7] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing3, TilePiece.Direction.Down);
			}

			// crossing 3
			if (ret == null && t[0] != null && t[1] != null && t[2] != null && t[3] != null)
			{
					 if (t[4] != null && t[5] == null && t[6] == null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing4, TilePiece.Direction.Right);
				else if (t[4] == null && t[5] != null && t[6] != null && t[7] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing4, TilePiece.Direction.Up);
			}

			// junction 2
			if (ret == null)
			{
					 if (t[0] != null && t[1] != null && t[6] != null && t[3] != null && t[7] != null && t[2] != null && t[4] == null && t[5] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing5, TilePiece.Direction.Up);
				else if (t[0] != null && t[1] != null && t[4] != null && t[2] != null && t[5] != null && t[3] != null && t[6] == null && t[7] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing5, TilePiece.Direction.Down);
				else if (t[3] != null && t[2] != null && t[6] != null && t[0] != null && t[4] != null && t[1] != null && t[7] == null && t[5] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing5, TilePiece.Direction.Left);
				else if (t[3] != null && t[2] != null && t[7] != null && t[1] != null && t[5] != null && t[0] != null && t[6] == null && t[4] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing5, TilePiece.Direction.Right);
			}

			// junction 3
			if (ret == null)
			{
					 if (t[3] == null && t[5] == null && t[0] != null && t[1] != null && t[2] != null && t[4] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction2, TilePiece.Direction.Up);
				else if (t[1] == null && t[4] == null && t[3] != null && t[2] != null && t[0] != null && t[6] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction2, TilePiece.Direction.Right);
				else if (t[2] == null && t[6] == null && t[0] != null && t[1] != null && t[3] != null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction2, TilePiece.Direction.Down);
				else if (t[0] == null && t[7] == null && t[3] != null && t[2] != null && t[1] != null && t[5] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction2, TilePiece.Direction.Left);
			}

			// junction 4
			if (ret == null)
			{
					 if (t[3] == null && t[4] == null && t[0] != null && t[1] != null && t[2] != null && t[5] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction3, TilePiece.Direction.Up);
				else if (t[1] == null && t[6] == null && t[3] != null && t[2] != null && t[0] != null && t[4] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction3, TilePiece.Direction.Right);
				else if (t[2] == null && t[7] == null && t[0] != null && t[1] != null && t[3] != null && t[6] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction3, TilePiece.Direction.Down);
				else if (t[0] == null && t[5] == null && t[3] != null && t[2] != null && t[1] != null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction3, TilePiece.Direction.Left);
			}

			// corner 2
			if (ret == null)
			{
					 if (t[1] != null && t[3] != null && t[7] != null && t[0] == null && t[2] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner2, TilePiece.Direction.Left);
				else if (t[1] != null && t[2] != null && t[5] != null && t[0] == null && t[3] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner2, TilePiece.Direction.Up);
				else if (t[0] != null && t[2] != null && t[4] != null && t[1] == null && t[3] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner2, TilePiece.Direction.Right);
				else if (t[0] != null && t[3] != null && t[6] != null && t[1] == null && t[2] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner2, TilePiece.Direction.Down);
			}

			// Crossing2
			if (ret == null)
			{
				if (t[0] != null && t[1] != null && t[3] != null && t[2] != null)
				{
						 if (t[4] == null && t[5] != null && t[6] != null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing2, TilePiece.Direction.Right);
					else if (t[4] != null && t[5] == null && t[6] != null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing2, TilePiece.Direction.Up);
					else if (t[4] != null && t[5] != null && t[6] == null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing2, TilePiece.Direction.Down);
					else if (t[4] != null && t[5] != null && t[6] != null && t[7] == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing2, TilePiece.Direction.Left);
				}
			}

			// one side
			if (ret == null)
			{
					 if (t[3] == null && t[0] != null && t[1] != null && t[4] != null && t[2] != null && t[5] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.One_Side, TilePiece.Direction.Right);
				else if (t[2] == null && t[0] != null && t[1] != null && t[6] != null && t[3] != null && t[7] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.One_Side, TilePiece.Direction.Left);
				else if (t[0] == null && t[2] != null && t[3] != null && t[7] != null && t[1] != null && t[5] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.One_Side, TilePiece.Direction.Up);
				else if (t[1] == null && t[2] != null && t[3] != null && t[6] != null && t[0] != null && t[4] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.One_Side, TilePiece.Direction.Down);
			}

			// crossing
			if (ret==null && t[0] != null && t[1] != null && t[2] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Crossing1, TilePiece.Direction.Up);

			// junction
			if (ret == null)
			{
				if (t[0] != null && t[1] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction1, TilePiece.Direction.Down);
				else if (t[0] != null && t[2] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction1, TilePiece.Direction.Right);
				else if (t[0] != null && t[1] != null && t[2] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction1, TilePiece.Direction.Up);
				else if (t[1] != null && t[2] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Junction1, TilePiece.Direction.Left);
			}

			// corner
			if (ret == null)
			{
				if (t[1] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner1, TilePiece.Direction.Left);
				else if (t[1] != null && t[2] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner1, TilePiece.Direction.Up);
				else if (t[0] != null && t[2] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner1, TilePiece.Direction.Right);
				else if (t[0] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Corner1, TilePiece.Direction.Down);
			}

			// sides
			if (ret == null)
			{
				if (t[0] != null && t[1] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Sides, TilePiece.Direction.Right);
				else if (t[2] != null && t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Sides, TilePiece.Direction.Up);
			}

			// dead_end
			if (ret == null)
			{
				if (t[0] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Dead_End, TilePiece.Direction.Right);
				else if (t[1] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Dead_End, TilePiece.Direction.Left);
				else if (t[2] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Dead_End, TilePiece.Direction.Up);
				else if (t[3] != null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Dead_End, TilePiece.Direction.Down);
			}

			// default is to spawn single
			if (ret == null) ret = SpawnAutoTilePiece(mainPiece, x, y, setIdx, tileIdx, floorLevel, TilePiece.Kind.Single, TilePiece.Direction.Up);

			return ret;
		}

		private CalculatedAutoSpawnInfo Terrain_CalculateAutoSpawnInfos(int x, int y, TilePiece placedFloor)
		{	// 6  3  7
			// 0  *  1
			// 4  2  5
			TilePiece[] t = { GetTerrainTileAt(x - 1, y), GetTerrainTileAt(x + 1, y), GetTerrainTileAt(x, y - 1), GetTerrainTileAt(x, y + 1), GetTerrainTileAt(x - 1, y - 1), GetTerrainTileAt(x + 1, y - 1), GetTerrainTileAt(x - 1, y + 1), GetTerrainTileAt(x + 1, y + 1), GetTerrainTileAt(x, y) };

			int b = 0, aa = 0, bb = 0;
			int[] l = new int[] { 199, 299, 399, 499 }; // it is important to have these huge differenes in values so taht code below can assume a few thinsg (like l[a]+1 wont equal l[b] if level a and b was not explicitly set to proper values in the code below)
			TilePiece.Direction[] d = new TilePiece.Direction[] { TilePiece.Direction.Invalid, TilePiece.Direction.Invalid, TilePiece.Direction.Invalid, TilePiece.Direction.Invalid };

			int lv = 0;
			TilePiece.Kind tp = TilePiece.Kind.None;
			TilePiece.Direction dir = TilePiece.Direction.Up;

			for (int a = 0; a < 4; a += 2)
			{
				// reset 'calculated' levels and directions
				l[0] = 199; l[1] = 299; l[2] = 399; l[3] = 499;
				d[0] = TilePiece.Direction.Invalid; d[1] = TilePiece.Direction.Invalid;
				d[2] = TilePiece.Direction.Invalid; d[3] = TilePiece.Direction.Invalid;

				// B is opposite to A and AA/BB will be 90* to A and B
				if (a == 0) { b = 1; aa = 2; bb = 3; }
				if (a == 2) { b = 3; aa = 0; bb = 1; }

				// *** Determine the height of A's connecting side
				if (t[a] != null)
				{
					d[a] = t[a].faceDir; // default the face direction
					if (t[a].kind == TilePiece.Kind.Floor)
					{
						l[a] = t[a].floorLevel;
						// always assume floors point in correct direction (in this case inward)
						if (a == 0) d[a] = TilePiece.Direction.Right;
						else if (a == 2) d[a] = TilePiece.Direction.Up;
					}
					else if (t[a].kind == TilePiece.Kind.Wall)
					{	// if the tile points inward then next tile will connect to its bottom, else the new tile connects to top
						if (a == 0 && t[a].faceDir == TilePiece.Direction.Right) l[a] = t[a].floorLevel - 1;
						if (a == 0 && t[a].faceDir == TilePiece.Direction.Left) l[a] = t[a].floorLevel;
						if (a == 2 && t[a].faceDir == TilePiece.Direction.Up) l[a] = t[a].floorLevel - 1;
						if (a == 2 && t[a].faceDir == TilePiece.Direction.Down) l[a] = t[a].floorLevel;
					}
					else if (t[a].kind == TilePiece.Kind.Corner1)
					{	// corner1 can only be connected at its top sides, so only when it looks outward
						if ((a == 0 && (t[a].faceDir == TilePiece.Direction.Down || t[a].faceDir == TilePiece.Direction.Left)) ||
							(a == 2 && (t[a].faceDir == TilePiece.Direction.Down || t[a].faceDir == TilePiece.Direction.Right)))
						{
							l[a] = t[a].floorLevel;
							// wall check needs some kinda direction, so fake point corner now in one that will make sense for that test
							if (a == 0) d[a] = TilePiece.Direction.Left;
							else if (a == 2) d[a] = TilePiece.Direction.Up;
						}
					}
					else if (t[a].kind == TilePiece.Kind.Corner2)
					{	// corner2 can only be connected at its bottom sides, so only when it looks inward
						if ((a == 0 && (t[a].faceDir == TilePiece.Direction.Up || t[a].faceDir == TilePiece.Direction.Right)) ||
							(a == 2 && (t[a].faceDir == TilePiece.Direction.Up || t[a].faceDir == TilePiece.Direction.Left)))
						{
							l[a] = t[a].floorLevel - 1;
							// wall check needs some kinda direction, so fake point corner now in one that will make sense for that test
							if (a == 0) d[a] = TilePiece.Direction.Right;
							else if (a == 2) d[a] = TilePiece.Direction.Up;
						}
					}
				}

				// *** Determine the height of B's connecting side
				if (t[b] != null)
				{
					d[b] = t[b].faceDir; // default the face direction
					if (t[b].kind == TilePiece.Kind.Floor)
					{
						l[b] = t[b].floorLevel;
						// always assume floors point in correct direction (in this case inward)
						if (b == 1) d[b] = TilePiece.Direction.Left;
						else if (b == 3) d[b] = TilePiece.Direction.Down;
					}
					else if (t[b].kind == TilePiece.Kind.Wall)
					{	// if the tile points inward then next tile will connect to its bottom, else the new tile connects to top
						if (b == 1 && t[b].faceDir == TilePiece.Direction.Right) l[b] = t[b].floorLevel;
						if (b == 1 && t[b].faceDir == TilePiece.Direction.Left) l[b] = t[b].floorLevel - 1;
						if (b == 3 && t[b].faceDir == TilePiece.Direction.Up) l[b] = t[b].floorLevel;
						if (b == 3 && t[b].faceDir == TilePiece.Direction.Down) l[b] = t[b].floorLevel - 1;
					}
					else if (t[b].kind == TilePiece.Kind.Corner1)
					{	// corner1 can only be connected at its top sides, so only when it looks outward
						if ((b == 1 && (t[b].faceDir == TilePiece.Direction.Up || t[b].faceDir == TilePiece.Direction.Right)) ||
							(b == 3 && (t[b].faceDir == TilePiece.Direction.Up || t[b].faceDir == TilePiece.Direction.Left)))
						{
							l[b] = t[b].floorLevel;
							// wall check needs some kinda direction, so fake point corner now in one that will make sense for that test
							if (b == 1) d[b] = TilePiece.Direction.Right;
							else if (b == 3) d[b] = TilePiece.Direction.Down;
						}
					}
					else if (t[b].kind == TilePiece.Kind.Corner2)
					{	// corner2 can only be connected at its bottom sides, so only when it looks inward
						if ((b == 1 && (t[b].faceDir == TilePiece.Direction.Down || t[b].faceDir == TilePiece.Direction.Left)) ||
							(b == 3 && (t[b].faceDir == TilePiece.Direction.Down || t[b].faceDir == TilePiece.Direction.Right)))
						{
							l[b] = t[b].floorLevel - 1;
							// wall check needs some kinda direction, so fake point corner now in one that will make sense for that test
							if (b == 1) d[b] = TilePiece.Direction.Left;
							else if (b == 3) d[b] = TilePiece.Direction.Up;
						}
					}
				}

				// *** Determine the height of AA's connecting side
				if (t[aa] != null)
				{
					d[aa] = t[aa].faceDir; // default the face direction
					if (t[aa].kind == TilePiece.Kind.Floor)
					{
						l[aa] = t[aa].floorLevel;
						// always assume floors point in correct direction (in this case inward)
						if (aa == 0) d[aa] = TilePiece.Direction.Right;
						else if (aa == 2) d[aa] = TilePiece.Direction.Up;
					}
					else if (t[aa].kind == TilePiece.Kind.Wall)
					{	// if the tile points inward then next tile will connect to its bottom, else the new tile connects to top
						if (aa == 0 && t[aa].faceDir == TilePiece.Direction.Right) l[aa] = t[aa].floorLevel - 1;
						if (aa == 0 && t[aa].faceDir == TilePiece.Direction.Left) l[aa] = t[aa].floorLevel;
						if (aa == 2 && t[aa].faceDir == TilePiece.Direction.Up) l[aa] = t[aa].floorLevel - 1;
						if (aa == 2 && t[aa].faceDir == TilePiece.Direction.Down) l[aa] = t[aa].floorLevel;
					}
					else if (t[aa].kind == TilePiece.Kind.Corner1)
					{	// corner1 can only be connected at its top sides, so only when it looks outward
						if ((aa == 0 && (t[aa].faceDir == TilePiece.Direction.Down || t[aa].faceDir == TilePiece.Direction.Left)) ||
							(aa == 2 && (t[aa].faceDir == TilePiece.Direction.Down || t[aa].faceDir == TilePiece.Direction.Right))
							) { l[aa] = t[aa].floorLevel; }
					}
					else if (t[aa].kind == TilePiece.Kind.Corner2)
					{	// corner2 can only be connected at its bottom sides, so only when it looks inward
						if ((aa == 0 && (t[aa].faceDir == TilePiece.Direction.Up || t[aa].faceDir == TilePiece.Direction.Right)) ||
							(aa == 2 && (t[aa].faceDir == TilePiece.Direction.Up || t[aa].faceDir == TilePiece.Direction.Left))
							) { l[aa] = t[aa].floorLevel - 1; }
					}
				}

				// *** Determine the height of BB's connecting side
				if (t[bb] != null)
				{
					d[bb] = t[bb].faceDir; // default the face direction
					if (t[bb].kind == TilePiece.Kind.Floor)
					{
						l[bb] = t[bb].floorLevel;
						// always assume floors point in correct direction (in this case inward)
						if (bb == 1) d[bb] = TilePiece.Direction.Left;
						else if (bb == 3) d[bb] = TilePiece.Direction.Down;
					}
					else if (t[bb].kind == TilePiece.Kind.Wall)
					{	// if the tile points inward then next tile will connect to its bottom, else the new tile connects to top
						if (bb == 1 && t[bb].faceDir == TilePiece.Direction.Right) l[bb] = t[bb].floorLevel;
						if (bb == 1 && t[bb].faceDir == TilePiece.Direction.Left) l[bb] = t[bb].floorLevel - 1;
						if (bb == 3 && t[bb].faceDir == TilePiece.Direction.Up) l[bb] = t[bb].floorLevel;
						if (bb == 3 && t[bb].faceDir == TilePiece.Direction.Down) l[bb] = t[bb].floorLevel - 1;
					}
					else if (t[bb].kind == TilePiece.Kind.Corner1)
					{	// corner1 can only be connected at its top sides, so only when it looks outward
						if ((bb == 1 && (t[bb].faceDir == TilePiece.Direction.Up || t[bb].faceDir == TilePiece.Direction.Right)) ||
							(bb == 3 && (t[bb].faceDir == TilePiece.Direction.Up || t[bb].faceDir == TilePiece.Direction.Left))
							) { l[bb] = t[bb].floorLevel; }
					}
					else if (t[bb].kind == TilePiece.Kind.Corner2)
					{	// corner2 can only be connected at its bottom sides, so only when it looks inward
						if ((bb == 1 && (t[bb].faceDir == TilePiece.Direction.Down || t[bb].faceDir == TilePiece.Direction.Left)) ||
							(bb == 3 && (t[bb].faceDir == TilePiece.Direction.Down || t[bb].faceDir == TilePiece.Direction.Right))
							) { l[bb] = t[bb].floorLevel - 1; }
					}
				}

				// ****************************************************************************************************
				// *** Test if CORNER 1 can be formed (only run the test while A == 0 since specific tests inside invalidate any other situation of A)
				// NOTE! Do not use l[x] for test of 'side' pieces cause it is only valid if those pieces pointed inward/outward

				if (a == 0)
				{
					if (l[aa] == l[a])
					{	// Up: A and AA, with B and BB at sides
						if (t[b] != null && t[bb] != null)
						{
							if (((t[b].kind != TilePiece.Kind.Floor && t[b].faceDir == TilePiece.Direction.Up && (t[b].kind == TilePiece.Kind.Corner2 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Left && t[b].kind == TilePiece.Kind.Corner1)) ||
								((t[bb].kind != TilePiece.Kind.Floor && t[bb].faceDir == TilePiece.Direction.Right && (t[bb].kind == TilePiece.Kind.Corner1 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Up && t[bb].kind == TilePiece.Kind.Corner2)))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner1;
								lv = l[a]; break;
							}
						}
						else if (t[b] != null)
						{
							if ((t[b].faceDir == TilePiece.Direction.Up && (t[b].kind == TilePiece.Kind.Corner2 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Left && t[b].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner1;
								lv = l[a]; break;
							}
						}
						else if (t[bb] != null)
						{
							if ((t[bb].faceDir == TilePiece.Direction.Right && (t[bb].kind == TilePiece.Kind.Corner1 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Up && t[bb].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner1;
								lv = l[a]; break;
							}
						}
					}
					else if (t[b] != null && t[bb] != null)
					{	// check if the two sides are fine with at least one top side as control
						if (((t[b].faceDir == TilePiece.Direction.Up && (t[b].kind == TilePiece.Kind.Corner2 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Left && t[b].kind == TilePiece.Kind.Corner1)) &&
							((t[bb].faceDir == TilePiece.Direction.Right && (t[bb].kind == TilePiece.Kind.Corner1 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Up && t[bb].kind == TilePiece.Kind.Corner2)))
						{
							if (t[bb].floorLevel == t[b].floorLevel && (l[a] == t[b].floorLevel || l[aa] == t[b].floorLevel))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner1;
								lv = t[b].floorLevel; break;
							}
						}
					}

					if (l[bb] == l[a])
					{	// Right: A and BB, with B and AA at sides
						if (t[b] != null && t[aa] != null)
						{
							if (((t[aa].kind != TilePiece.Kind.Floor && t[b].faceDir == TilePiece.Direction.Down && (t[b].kind == TilePiece.Kind.Corner1 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Right && t[b].kind == TilePiece.Kind.Corner2)) ||
								((t[b].kind != TilePiece.Kind.Floor && t[aa].faceDir == TilePiece.Direction.Right && (t[aa].kind == TilePiece.Kind.Corner2 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Up && t[aa].kind == TilePiece.Kind.Corner1)))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner1;
								lv = l[a]; break;
							}
						}
						else if (t[b] != null)
						{
							if ((t[b].faceDir == TilePiece.Direction.Down && (t[b].kind == TilePiece.Kind.Corner1 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Right && t[b].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner1;
								lv = l[a]; break;
							}
						}
						else if (t[aa] != null)
						{
							if ((t[aa].faceDir == TilePiece.Direction.Right && (t[aa].kind == TilePiece.Kind.Corner2 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Up && t[aa].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner1;
								lv = l[a]; break;
							}
						}
					}
					else if (t[b] != null && t[aa] != null)
					{	// check if the two sides are fine with at least one top side as control
						if (((t[b].faceDir == TilePiece.Direction.Down && (t[b].kind == TilePiece.Kind.Corner1 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Right && t[b].kind == TilePiece.Kind.Corner2)) &&
							 ((t[aa].faceDir == TilePiece.Direction.Right && (t[aa].kind == TilePiece.Kind.Corner2 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Up && t[aa].kind == TilePiece.Kind.Corner1)))
						{
							if (t[aa].floorLevel == t[b].floorLevel && (l[a] == t[b].floorLevel || l[bb] == t[b].floorLevel))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner1;
								lv = t[b].floorLevel; break;
							}
						}
					}

					if (l[bb] == l[b])
					{	// Down: B and BB, with A and AA at sides
						if (t[a] != null && t[aa] != null)
						{
							if (((t[aa].kind != TilePiece.Kind.Floor && t[a].faceDir == TilePiece.Direction.Down && (t[a].kind == TilePiece.Kind.Corner2 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Right && t[a].kind == TilePiece.Kind.Corner1)) ||
								((t[a].kind != TilePiece.Kind.Floor && t[aa].faceDir == TilePiece.Direction.Left && (t[aa].kind == TilePiece.Kind.Corner1 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Down && t[aa].kind == TilePiece.Kind.Corner2)))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner1;
								lv = l[b]; break;
							}
						}
						else if (t[a] != null)
						{
							if ((t[a].faceDir == TilePiece.Direction.Down && (t[a].kind == TilePiece.Kind.Corner2 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Right && t[a].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner1;
								lv = l[b]; break;
							}
						}
						else if (t[aa] != null)
						{
							if ((t[aa].faceDir == TilePiece.Direction.Left && (t[aa].kind == TilePiece.Kind.Corner1 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Down && t[aa].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner1;
								lv = l[b]; break;
							}
						}
					}
					else if (t[a] != null && t[aa] != null)
					{	// check if the two sides are fine with at least one top side as control
						if (((t[a].faceDir == TilePiece.Direction.Down && (t[a].kind == TilePiece.Kind.Corner2 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Right && t[a].kind == TilePiece.Kind.Corner1)) &&
							((t[aa].faceDir == TilePiece.Direction.Left && (t[aa].kind == TilePiece.Kind.Corner1 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Down && t[aa].kind == TilePiece.Kind.Corner2)))
						{
							if (t[aa].floorLevel == t[a].floorLevel && (l[bb] == t[a].floorLevel || l[b] == t[a].floorLevel))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner1;
								lv = t[a].floorLevel; break;
							}
						}
					}

					if (l[aa] == l[b])
					{	// Left: B and AA, with A and BB at sides
						if (t[a] != null && t[bb] != null)
						{
							if (((t[bb].kind != TilePiece.Kind.Floor && t[a].faceDir == TilePiece.Direction.Up && (t[a].kind == TilePiece.Kind.Corner1 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Left && t[a].kind == TilePiece.Kind.Corner2)) ||
								((t[a].kind != TilePiece.Kind.Floor && t[bb].faceDir == TilePiece.Direction.Left && (t[bb].kind == TilePiece.Kind.Corner2 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Down && t[bb].kind == TilePiece.Kind.Corner1)))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner1;
								lv = l[b]; break;
							}
						}
						else if (t[a] != null)
						{
							if ((t[a].faceDir == TilePiece.Direction.Up && (t[a].kind == TilePiece.Kind.Corner1 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Left && t[a].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner1;
								lv = l[b]; break;
							}
						}
						else if (t[bb] != null)
						{
							if ((t[bb].faceDir == TilePiece.Direction.Left && (t[bb].kind == TilePiece.Kind.Corner2 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Down && t[bb].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner1;
								lv = l[b]; break;
							}
						}
					}
					else if (t[a] != null && t[bb] != null)
					{	// check if the two sides are fine with at least one top side as control
						if (((t[a].faceDir == TilePiece.Direction.Up && (t[a].kind == TilePiece.Kind.Corner1 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Left && t[a].kind == TilePiece.Kind.Corner2)) &&
							((t[bb].faceDir == TilePiece.Direction.Left && (t[bb].kind == TilePiece.Kind.Corner2 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Down && t[bb].kind == TilePiece.Kind.Corner1)))
						{
							if (t[bb].floorLevel == t[a].floorLevel && (l[aa] == t[a].floorLevel || l[b] == t[a].floorLevel))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner1;
								lv = t[a].floorLevel; break;
							}
						}
					}

				}

				// ****************************************************************************************************
				// *** Test if CORNER 2 can be formed (only run the test while A == 0 since specific tests inside invalidate any other situation of A)
				// NOTE! Do not use l[x] for test of 'side' pieces cause it is only valid if those pieces pointed inward/outward

				if (a == 0)
				{
					if (l[bb] == l[b])
					{	// Up: B and BB, with A and AA at sides
						if (t[a] != null && t[aa] != null)
						{
							if (((t[aa].kind != TilePiece.Kind.Floor && t[a].faceDir == TilePiece.Direction.Up && (t[a].kind == TilePiece.Kind.Corner1 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Left && t[a].kind == TilePiece.Kind.Corner2)) ||
								((t[a].kind != TilePiece.Kind.Floor && t[aa].faceDir == TilePiece.Direction.Right && (t[aa].kind == TilePiece.Kind.Corner2 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Up && t[aa].kind == TilePiece.Kind.Corner1)))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner2;
								lv = t[a].floorLevel; break;
							}
						}
						else if (t[a] != null)
						{
							if ((t[a].faceDir == TilePiece.Direction.Up && (t[a].kind == TilePiece.Kind.Corner1 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Left && t[a].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner2;
								lv = t[a].floorLevel; break;
							}
						}
						else if (t[aa] != null)
						{
							if ((t[aa].faceDir == TilePiece.Direction.Right && (t[aa].kind == TilePiece.Kind.Corner2 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Up && t[aa].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner2;
								lv = t[aa].floorLevel; break;
							}
						}
					}
					else if (t[a] != null && t[aa] != null)
					{	// check if the two sides are fine with at least one bottom side as control
						if (((t[a].faceDir == TilePiece.Direction.Up && (t[a].kind == TilePiece.Kind.Corner1 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Left && t[a].kind == TilePiece.Kind.Corner2)) &&
							((t[aa].faceDir == TilePiece.Direction.Right && (t[aa].kind == TilePiece.Kind.Corner2 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Up && t[aa].kind == TilePiece.Kind.Corner1)))
						{
							if (t[aa].floorLevel == t[a].floorLevel && (l[b] == t[a].floorLevel - 1 || l[bb] == t[a].floorLevel - 1))
							{
								dir = TilePiece.Direction.Up;
								tp = TilePiece.Kind.Corner2;
								lv = t[a].floorLevel; break;
							}
						}
					}

					if (l[aa] == l[b])
					{	// Right: B and AA, with A and BB at sides
						if (t[a] != null && t[bb] != null)
						{
							if (((t[bb].kind != TilePiece.Kind.Floor && t[a].faceDir == TilePiece.Direction.Down && (t[a].kind == TilePiece.Kind.Corner2 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Right && t[a].kind == TilePiece.Kind.Corner1)) ||
								((t[a].kind != TilePiece.Kind.Floor && t[bb].faceDir == TilePiece.Direction.Right && (t[bb].kind == TilePiece.Kind.Corner1 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Up && t[bb].kind == TilePiece.Kind.Corner2)))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner2;
								lv = t[a].floorLevel; break;
							}
						}
						else if (t[a] != null)
						{
							if ((t[a].faceDir == TilePiece.Direction.Down && (t[a].kind == TilePiece.Kind.Corner2 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Right && t[a].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner2;
								lv = t[a].floorLevel; break;
							}
						}
						else if (t[bb] != null)
						{
							if ((t[bb].faceDir == TilePiece.Direction.Right && (t[bb].kind == TilePiece.Kind.Corner1 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Up && t[bb].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner2;
								lv = t[bb].floorLevel; break;
							}
						}
					}
					else if (t[a] != null && t[bb] != null)
					{	// check if the two sides are fine with at least one bottom side as control
						if (((t[a].faceDir == TilePiece.Direction.Down && (t[a].kind == TilePiece.Kind.Corner2 || t[a].kind == TilePiece.Kind.Wall)) || (t[a].faceDir == TilePiece.Direction.Right && t[a].kind == TilePiece.Kind.Corner1)) &&
							((t[bb].faceDir == TilePiece.Direction.Right && (t[bb].kind == TilePiece.Kind.Corner1 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Up && t[bb].kind == TilePiece.Kind.Corner2)))
						{
							if (t[bb].floorLevel == t[a].floorLevel && (l[b] == t[a].floorLevel - 1 || l[aa] == t[a].floorLevel - 1))
							{
								dir = TilePiece.Direction.Right;
								tp = TilePiece.Kind.Corner2;
								lv = t[a].floorLevel; break;
							}
						}
					}

					if (l[aa] == l[a])
					{	// Down: A and AA, with B and BB at sides
						if (t[b] != null && t[bb] != null)
						{
							if (((t[bb].kind != TilePiece.Kind.Floor && t[b].faceDir == TilePiece.Direction.Down && (t[b].kind == TilePiece.Kind.Corner1 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Right && t[b].kind == TilePiece.Kind.Corner2)) ||
								((t[b].kind != TilePiece.Kind.Floor && t[bb].faceDir == TilePiece.Direction.Left && (t[bb].kind == TilePiece.Kind.Corner2 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Down && t[bb].kind == TilePiece.Kind.Corner1)))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner2;
								lv = t[b].floorLevel; ; break;
							}
						}
						else if (t[b] != null)
						{
							if ((t[b].faceDir == TilePiece.Direction.Down && (t[b].kind == TilePiece.Kind.Corner1 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Right && t[b].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner2;
								lv = t[b].floorLevel; break;
							}
						}
						if (t[bb] != null)
						{
							if ((t[bb].faceDir == TilePiece.Direction.Left && (t[bb].kind == TilePiece.Kind.Corner2 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Down && t[bb].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner2;
								lv = t[bb].floorLevel; break;
							}
						}
					}
					else if (t[b] != null && t[bb] != null)
					{	// check if the two sides are fine with at least one bottom side as control
						if (((t[b].faceDir == TilePiece.Direction.Down && (t[b].kind == TilePiece.Kind.Corner1 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Right && t[b].kind == TilePiece.Kind.Corner2)) &&
							((t[bb].faceDir == TilePiece.Direction.Left && (t[bb].kind == TilePiece.Kind.Corner2 || t[bb].kind == TilePiece.Kind.Wall)) || (t[bb].faceDir == TilePiece.Direction.Down && t[bb].kind == TilePiece.Kind.Corner1)))
						{
							if (t[bb].floorLevel == t[b].floorLevel && (l[a] == t[b].floorLevel - 1 || l[aa] == t[b].floorLevel - 1))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner2;
								lv = t[b].floorLevel; break;
							}
						}
					}

					if (l[bb] == l[a])
					{	// Left: A and BB, with B and AA at sides
						if (t[b] != null && t[aa] != null)
						{
							if (((t[aa].kind != TilePiece.Kind.Floor && t[b].faceDir == TilePiece.Direction.Up && (t[b].kind == TilePiece.Kind.Corner2 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Left && t[b].kind == TilePiece.Kind.Corner1)) ||
								((t[b].kind != TilePiece.Kind.Floor && t[aa].faceDir == TilePiece.Direction.Left && (t[aa].kind == TilePiece.Kind.Corner1 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Down && t[aa].kind == TilePiece.Kind.Corner2)))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner2;
								lv = t[b].floorLevel; break;
							}
						}
						else if (t[b] != null)
						{
							if ((t[b].faceDir == TilePiece.Direction.Up && (t[b].kind == TilePiece.Kind.Corner2 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Left && t[b].kind == TilePiece.Kind.Corner1))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner2;
								lv = t[b].floorLevel; break;
							}
						}
						else if (t[aa] != null)
						{
							if ((t[aa].faceDir == TilePiece.Direction.Left && (t[aa].kind == TilePiece.Kind.Corner1 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Down && t[aa].kind == TilePiece.Kind.Corner2))
							{
								dir = TilePiece.Direction.Left;
								tp = TilePiece.Kind.Corner2;
								lv = t[aa].floorLevel; break;
							}
						}
					}
					else if (t[b] != null && t[aa] != null)
					{	// check if the two sides are fine with at least one bottom side as control
						if (((t[b].faceDir == TilePiece.Direction.Up && (t[b].kind == TilePiece.Kind.Corner2 || t[b].kind == TilePiece.Kind.Wall)) || (t[b].faceDir == TilePiece.Direction.Left && t[b].kind == TilePiece.Kind.Corner1)) &&
							((t[aa].faceDir == TilePiece.Direction.Left && (t[aa].kind == TilePiece.Kind.Corner1 || t[aa].kind == TilePiece.Kind.Wall)) || (t[aa].faceDir == TilePiece.Direction.Down && t[aa].kind == TilePiece.Kind.Corner2)))
						{
							if (t[aa].floorLevel == t[b].floorLevel && (l[a] == t[b].floorLevel - 1 || l[bb] == t[b].floorLevel - 1))
							{
								dir = TilePiece.Direction.Down;
								tp = TilePiece.Kind.Corner2;
								lv = t[b].floorLevel; break;
							}
						}
					}

				}

				// ****************************************************************************************************
				// *** Test if FLOOR or WALL can be formed

				if (l[a] < 100 && l[b] < 100 &&
					(a == 0 && (d[a] == TilePiece.Direction.Right || d[a] == TilePiece.Direction.Left) && (d[b] == TilePiece.Direction.Right || d[b] == TilePiece.Direction.Left)) ||
					(a == 2 && (d[a] == TilePiece.Direction.Up || d[a] == TilePiece.Direction.Down) && (d[b] == TilePiece.Direction.Up || d[b] == TilePiece.Direction.Down)))
				{
					if (l[a] == l[b] + 1)
					{	// A is one higher than B, can spawn a wall pointing away from A, on same level as A
						if (a == 0) dir = TilePiece.Direction.Right;
						if (a == 2) dir = TilePiece.Direction.Up;
						tp = TilePiece.Kind.Wall;
						lv = l[a]; break;
					}
					else if (l[a] == l[b] - 1)
					{	// A is one lower than B, can spawn a wall pointing towards A, on a level higher than A
						if (a == 0) dir = TilePiece.Direction.Left;
						if (a == 2) dir = TilePiece.Direction.Down;
						tp = TilePiece.Kind.Wall;
						lv = l[b]; break;
					}
					else if (l[a] == l[b])
					{	// both on same level, spawn a floor
						tp = TilePiece.Kind.Floor;
						lv = l[a];

						// dont overwrite existing floor, except if not on draw level
						if (t[8] != null)
						{
							if (t[8].kind == TilePiece.Kind.Floor || t[8].floorLevel != placedFloor.floorLevel)
							{
								tp = TilePiece.Kind.None;
								continue;
							}
						}

						// don't break yet since this floor might not be ultimate choise (except if on drawlevel)
						if (lv == placedFloor.floorLevel) break;
					}
				}

			}

			// --------------------------------------------------------------------------------------------------------
			// DONE
			if (tp != TilePiece.Kind.None)
			{
				//return new CalculatedAutoSpawnInfo { type = tp, faceDirection = dir, setIdx = t[s].setIdx, tileIdx = t[s].tileIdx, floorLevel = lv };
				return new CalculatedAutoSpawnInfo { type = tp, faceDirection = dir, setIdx = placedFloor.setIdx, tileIdx = placedFloor.tileIdx, floorLevel = lv };
			}

			return null;
		}

		private List<CalculatedAutoSpawnInfo> Dungeon_CalculateAutoSpawnInfos(int x, int y)
		{
			List<CalculatedAutoSpawnInfo> nfo = new List<CalculatedAutoSpawnInfo>();

			// helpers
			TilePiece.Direction dir = TilePiece.Direction.Up;
			List<int> levelDone = new List<int>();
			int a = 0, b = 0, c = 0, d = 0, e = 0;
			int upperSet = -1, upperTile = -1;

			// 6  3  7 [ tile (8) is where the walls and/or corners will be placed depending on what is going on around it ]
			// 0  8  1
			// 4  2  5
			TilePiece[] f = { GetDungeonFloorAt(x - 1, y), GetDungeonFloorAt(x + 1, y), GetDungeonFloorAt(x, y - 1), GetDungeonFloorAt(x, y + 1), GetDungeonFloorAt(x - 1, y - 1), GetDungeonFloorAt(x + 1, y - 1), GetDungeonFloorAt(x - 1, y + 1), GetDungeonFloorAt(x + 1, y + 1), GetDungeonFloorAt(x, y) };
			int[] l = new int[f.Length]; // floor level of f
			for (int i = 0; i < f.Length; i++) l[i] = f[i] == null ? 999 : f[i].floorLevel;

			// * * * [ check if pillar. tiles on 4 sides ]
			// * - *
			// * * *
			if (f[0] != null && f[1] != null && f[2] != null && f[3] != null)
			{
				// if 4 tiles on same level,
				if (l[8] > l[0] && l[0] != 999 && l[1] == l[0] && l[2] == l[0] && l[3] == l[0])
				{
					dir = TilePiece.Direction.Up;
					nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Pillar, faceDirection = dir, setIdx = f[0].setIdx, tileIdx = f[0].tileIdx, floorLevel = l[0] });

					// draw an upper wall if tile was level -1, then it was a pit and candidate for testing if upper walls are used
					if (f[8] == null && DungeonAutoTileSupportsUpper(db.autoTiles[f[0].setIdx].tiles[f[0].tileIdx], ref upperSet, ref upperTile))
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Pillar, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = l[0] + 1 });
					}

					return nfo;
				}

				// else, with not all floors on same level, do a bit more complicated check to see if there should not still be a pillar above lower level floor(s)
				else if (f[8] == null)
				{
					for (int i = 0; i < 4; i++)
					{
						if (l[i] != -1) continue; // only pits can have upper walls
						if (false == DungeonAutoTileSupportsUpper(db.autoTiles[f[i].setIdx].tiles[f[i].tileIdx], ref upperSet, ref upperTile)) continue;

						// check if level above can have pillar
						for (int j = 0; j < 4; j++)
						{
							if (l[j] != 0) continue; // is not an upper floor
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Pillar, faceDirection = TilePiece.Direction.Up, setIdx = upperSet, tileIdx = upperSet, floorLevel = 0 });
							levelDone.Add(0); // upper done
							break;
						}
						if (levelDone.Contains(0)) break;
					}
				}
			}

			// * * * [ check if corner 3. tiles on 3 sides ]
			// * - *
			// * - *		
			for (int i = 0; i < 4; i++)
			{
				if (levelDone.Contains(l[i])) continue;

				if (i == 0) { a = 2; b = 3; dir = TilePiece.Direction.Left; }
				if (i == 1) { a = 2; b = 3; dir = TilePiece.Direction.Right; }
				if (i == 2) { a = 0; b = 1; dir = TilePiece.Direction.Down; }
				if (i == 3) { a = 0; b = 1; dir = TilePiece.Direction.Up; }

				if (f[i] != null && f[a] != null && f[b] != null)
				{
					// check if 3 floors on same level
					if (l[8] > l[i] && l[a] == l[i] && l[b] == l[i])
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner3, faceDirection = dir, setIdx = f[i].setIdx, tileIdx = f[i].tileIdx, floorLevel = l[i] });
						levelDone.Add(l[i]);

						// check if should add an upper corner3 (only pits can have uppoer wall)
						if (f[8] == null && l[i] == -1)
						{
							if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[i].setIdx].tiles[f[i].tileIdx], ref upperSet, ref upperTile))
							{
								nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner3, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
								levelDone.Add(0);
							}
						}
					}

					// else, check if should place at least upper corner3
					else if (f[8] == null)
					{
						c = i; d = i;
						if (l[a] < l[c]) c = a; if (l[b] < l[c]) c = b; // c is the lower tile
						if (l[a] > l[d]) d = a; if (l[b] > l[d]) d = b; // d is the higher tile

						// c should be a pit (-1) to continue
						if (l[c] == -1)
						{
							if (levelDone.Contains(l[d]) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[c].setIdx].tiles[f[c].tileIdx], ref upperSet, ref upperTile))
							{
								nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner3, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
								levelDone.Add(0);
							}
						}
					}
				}
			}

			// * - * [ check if a wall on two sides. need same level floor tiles on 2 sides ]
			// * - *
			// * - *
			for (int i = 0; i < 3; i += 2)
			{
				if (i == 0) { dir = TilePiece.Direction.Left; a = 0; b = 1; }
				if (i == 2) { dir = TilePiece.Direction.Down; a = 2; b = 3; }
				if (f[a] == null || f[b] == null) continue;

				List<int> toAdd = new List<int>();

				// wall 1 (a)
				if (levelDone.Contains(l[a]) == false && l[8] > l[a])
				{
					// either the floors should be on same level, or the other side will have araised wall
					if (l[a] == l[b] || (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[b].setIdx].tiles[f[b].tileIdx], ref upperSet, ref upperTile)))
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Wall, faceDirection = dir, setIdx = f[a].setIdx, tileIdx = f[a].tileIdx, floorLevel = l[a] });
						toAdd.Add(l[a]);
					}

					// check if should place upper walls
					if (f[8] == null && l[a] == -1)
					{
						if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[a].setIdx].tiles[f[a].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Wall, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
							toAdd.Add(0);
						}
					}
				}

				// wall 2 (a)
				dir = (dir == TilePiece.Direction.Down ? TilePiece.Direction.Up : TilePiece.Direction.Right);
				if (levelDone.Contains(l[b]) == false && l[8] > l[b])
				{
					// either the floors should be on same level, or the other side will have araised wall
					if (l[a] == l[b] || (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[a].setIdx].tiles[f[a].tileIdx], ref upperSet, ref upperTile)))
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Wall, faceDirection = dir, setIdx = f[b].setIdx, tileIdx = f[b].tileIdx, floorLevel = l[b] });
						toAdd.Add(l[b]);
					}

					// check if should place upper walls
					if (f[8] == null && l[b] == -1)
					{
						if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[b].setIdx].tiles[f[b].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Wall, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
							toAdd.Add(0);
						}
					}
				}

				foreach (int addMe in toAdd) levelDone.Add(addMe);
			}

			// * * * [ check if corner 2. need same level floor tiles on 2 sides ]
			// - - * [ also check if a corner1 should be included ]
			// - - *
			for (int i = 0; i < 4; i++)
			{
				if (i == 0) { dir = TilePiece.Direction.Left; a = 0; b = 3; d = 5; }
				if (i == 1) { dir = TilePiece.Direction.Right; a = 1; b = 2; d = 6; }
				if (i == 2) { dir = TilePiece.Direction.Down; a = 2; b = 0; d = 7; }
				if (i == 3) { dir = TilePiece.Direction.Up; a = 3; b = 1; d = 4; }
				if (f[a] == null || f[b] == null) continue;
				if (l[a] > l[b]) { c = b; b = a; a = c; } // a is lower floor, and b the higher one

				if (levelDone.Contains(l[a])) continue;

				if (l[8] > l[a])
				{
					List<int> toAdd = new List<int>();
					TilePiece.Direction dir2 = TilePiece.Direction.Down;
					if (dir == TilePiece.Direction.Down) dir2 = TilePiece.Direction.Up;
					else if (dir == TilePiece.Direction.Left) dir2 = TilePiece.Direction.Right;
					else if (dir == TilePiece.Direction.Right) dir2 = TilePiece.Direction.Left;

					c = 999;

					if (l[a] == l[b])
					{
						// add corner2
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner2, faceDirection = dir, setIdx = f[a].setIdx, tileIdx = f[a].tileIdx, floorLevel = l[a] });
						toAdd.Add(l[a]);
						c = l[a];

						// add corner1?
						if (l[d] == l[a] && f[d] != null)
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = dir2, setIdx = f[d].setIdx, floorLevel = l[d] });
							toAdd.Add(l[d]);
						}
					}

					// place upper level parts?
					e = (l[a] < l[b] ? a : b);
					if (f[8] == null && l[e] == -1)
					{
						// corner 2
						if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[e].setIdx].tiles[f[e].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner2, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
							toAdd.Add(0);
							c = 0;

							// corner 1
							if (f[d] != null)
							{
								nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = dir2, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
								//toAdd.Add(0); not needed
							}
						}
					}

					// special case for corner1
					if (c != 999 && f[d] != null && f[8] == null && (l[a] != l[d] || l[b] != l[d]) && levelDone.Contains(l[d]) == false)
					{
						if (c == l[d])
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = dir2, setIdx = f[d].setIdx, tileIdx = f[d].tileIdx, floorLevel = l[d] });
							toAdd.Add(l[d]);
						}

						// check if upper corner1 needed
						if (l[d] == -1 && levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[d].setIdx].tiles[f[d].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = dir2, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
							toAdd.Add(0);
						}
					}

					foreach (int addMe in toAdd) levelDone.Add(addMe);
				}
			}

			// - - * [ check if wall on one side. need same level floor tile on 1 side ]
			// - - * [ also check if should include none, one or two of corner1 shape ]
			// - - *
			for (int i = 0; i < 4; i++)
			{
				if (l[8] <= l[i] || f[i] == null) continue;
				if (levelDone.Contains(l[i])) continue;

				List<int> toAdd = new List<int>();

				if (i == 0) { dir = TilePiece.Direction.Left; a = 5; b = 7; }
				if (i == 1) { dir = TilePiece.Direction.Right; a = 6; b = 4; }
				if (i == 2) { dir = TilePiece.Direction.Down; a = 7; b = 6; }
				if (i == 3) { dir = TilePiece.Direction.Up; a = 4; b = 5; }

				nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Wall, faceDirection = dir, setIdx = f[i].setIdx, tileIdx = f[i].tileIdx, floorLevel = l[i] });
				toAdd.Add(l[i]);

				// add upper wall?
				if (f[8] == null && l[i] == -1)
				{
					if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[i].setIdx].tiles[f[i].tileIdx], ref upperSet, ref upperTile))
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Wall, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
						toAdd.Add(0);
					}
				}

				// add 1st corner1?
				//if (f[8] == null && f[a] != null && levelDone.Contains(l[a]) == false)
				if (l[8] > l[a] && f[a] != null && levelDone.Contains(l[a]) == false)
				{
					TilePiece.Direction thDir = TilePiece.Direction.Down;
					if (dir == TilePiece.Direction.Down) thDir = TilePiece.Direction.Up;
					else if (dir == TilePiece.Direction.Left) thDir = TilePiece.Direction.Right;
					else if (dir == TilePiece.Direction.Right) thDir = TilePiece.Direction.Left;

					if (l[i] <= l[a])
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = thDir, setIdx = f[a].setIdx, tileIdx = f[a].tileIdx, floorLevel = l[a] });
						toAdd.Add(l[a]);
					}

					// add upper corner
					if (l[a] == -1 && f[8] == null)
					{
						if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[a].setIdx].tiles[f[a].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = thDir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
							toAdd.Add(0);
						}
					}
				}

				// add 2nd corner1?
				//if (f[8] == null && f[b] != null && levelDone.Contains(l[b]) == false)
				if (l[8] > l[b] && f[b] != null && levelDone.Contains(l[b]) == false)
				{
					TilePiece.Direction thDir = TilePiece.Direction.Right;
					if (dir == TilePiece.Direction.Down) thDir = TilePiece.Direction.Left;
					else if (dir == TilePiece.Direction.Left) thDir = TilePiece.Direction.Up;
					else if (dir == TilePiece.Direction.Right) thDir = TilePiece.Direction.Down;

					if (l[i] <= l[b])
					{
						nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = thDir, setIdx = f[b].setIdx, tileIdx = f[b].tileIdx, floorLevel = l[b] });
						toAdd.Add(l[b]);
					}

					// add upper corner
					if (l[b] == -1 && f[8] == null)
					{
						if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[b].setIdx].tiles[f[b].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = thDir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
							toAdd.Add(0);
						}
					}
				}

				foreach (int addMe in toAdd) levelDone.Add(addMe);
			}

			// * - * [ check where corner1 should be placed ]
			// - - -
			// * - *
			for (int i = 4; i < 8; i++)
			{
				if (f[i] != null && l[8] > l[i])
				{
					if (levelDone.Contains(l[i])) continue;

					if (i == 4) { dir = TilePiece.Direction.Down; if (l[0] < l[i] || l[2] < l[i])continue; }
					if (i == 5) { dir = TilePiece.Direction.Right; if (l[1] < l[i] || l[2] < l[i])continue; }
					if (i == 6) { dir = TilePiece.Direction.Left; if (l[0] < l[i] || l[3] < l[i])continue; }
					if (i == 7) { dir = TilePiece.Direction.Up; if (l[1] < l[i] || l[3] < l[i])continue; }

					nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = dir, setIdx = f[i].setIdx, tileIdx = f[i].tileIdx, floorLevel = l[i] });

					// add upper corner
					if (f[8] == null && l[i] == -1)
					{
						if (levelDone.Contains(0) == false && DungeonAutoTileSupportsUpper(db.autoTiles[f[i].setIdx].tiles[f[i].tileIdx], ref upperSet, ref upperTile))
						{
							nfo.Add(new CalculatedAutoSpawnInfo { type = TilePiece.Kind.Corner1, faceDirection = dir, setIdx = upperSet, tileIdx = upperTile, floorLevel = 0 });
						}
					}
				}
			}

			return nfo;
		}

		private bool DungeonAutoTileSupportsUpper(DefAutoTile tile, ref int setIdx, ref int tileIdx)
		{
			setIdx = tile.upperSet;
			tileIdx = tile.upperTile;
			if (setIdx >= 0 && tileIdx >= 0) return true;
			return false;
		}

		private TilePiece GetDungeonFloorAt(int x, int y)
		{
			if (x >= 0 && y >= 0 && x < width && y < length)
			{
				int idx = y * width + x;
				TilePiece piece = (tiles[idx] == null ? null : tiles[idx].GetComponent<TilePiece>());
				if (piece != null)
				{
					if (db.autoTiles[piece.setIdx].kind != UniRPG.TileSetKind.Dungeon) return null;
					if (piece.kind == TilePiece.Kind.Floor) return piece;
				}
			}
			return null;
		}

		private TilePiece GetTerrainTileAt(int x, int y)
		{
			if (x >= 0 && y >= 0 && x < width && y < length)
			{
				int idx = y * width + x;
				TilePiece piece = (tiles[idx] == null ? null : tiles[idx].GetComponent<TilePiece>());
				if (piece != null)
				{
					if (db.autoTiles[piece.setIdx].kind == UniRPG.TileSetKind.Terrain) return piece;
				}
			}
			return null;
		}

		private TilePiece GetExpandingTileAt(int x, int y, int setIdx, int level)
		{
			if (x >= 0 && y >= 0 && x < width && y < length)
			{
				int idx = y * width + x;
				TilePiece piece = (tiles[idx] == null ? null : tiles[idx].GetComponent<TilePiece>());
				if (piece != null)
				{
					if (db.autoTiles[piece.setIdx].kind == UniRPG.TileSetKind.Expanding)
					{
						if (piece.setIdx == setIdx && piece.floorLevel == level) return piece;
					}

					if (piece.linkedPieces.Count > 0)
					{
						foreach (GameObject go in piece.linkedPieces)
						{
							TilePiece lp = go.GetComponent<TilePiece>();
							if (lp.setIdx == setIdx && lp.floorLevel == level) return lp;
						}
					}
				}
			}
			return null;
		}

		#endregion
		// ================================================================================================================
		#region (Plop)pables Specific

		public GameObject PlacePlop(Vector3 position, TilePiece.Direction direction, int setIdx, int plopIdx)
		{
			if (setIdx < 0 || setIdx >= db.plopSets.Count) return null;
			if (plopIdx < 0 || plopIdx >= db.plopSets[setIdx].plops.Count) return null;
			if (direction == TilePiece.Direction.Invalid) direction = TilePiece.Direction.Up;

			Vector3 r = Vector3.zero;
			r.y = (float)direction;

			// spawn it
			position += this.transform.position;
			GameObject go = (GameObject)Instantiate(db.plopSets[setIdx].plops[plopIdx], position, Quaternion.Euler(r));
			if (go)
			{
				if (plopsContainer == null)
				{
					GameObject parentGo = GameObject.Find("Plops");
					if (parentGo == null)
					{
						parentGo = new GameObject("Plops");
						plopsContainer = parentGo.transform;
					}
					else
					{
						plopsContainer = parentGo.transform;
					}
				}

				// plops are grouped by kind
				string groupName = db.plopSets[setIdx].kind.ToString();
				Transform container = plopsContainer.FindChild(groupName);
				if (container == null)
				{
					GameObject g = new GameObject(groupName);
					container = g.transform;
					container.parent = plopsContainer;
					container.localPosition = Vector3.zero;
					container.localRotation = Quaternion.identity;
				}

				go.transform.parent = container;

			}

			return go;
		}

		#endregion
		// ================================================================================================================
		#region Gizmos

		private static Color Grid3D_Color = new Color(1f, 1f, 1f, 0.3f);
		private static Color Grid3D_ColorOutline = new Color(1f, 1f, 1f, 0.6f);

		public bool gizmoGrid = true;							// draw the grid gizmo?
		public bool hideWireframes = true;

		// these are defined here and not in editor scripts cause they are needed in the Gizmo
		private int _ed_currentLevel = 0;						// height level to draw new tiles at
		public int ed_currentLevel { get { return _ed_currentLevel; } set { _ed_currentLevel = value; if (_ed_currentLevel > 10)_ed_currentLevel = 10; if (_ed_currentLevel < -10)_ed_currentLevel = -10; } }

		void OnDrawGizmos()
		{
			if (!enabled) return;
			if (!gizmoGrid) return;
			
			Vector3 pos = this.transform.position;
			pos.x -= tileSize / 2f;
			pos.z -= tileSize / 2f;
			pos.y += 0.01f + (ed_currentLevel * tileHeight);

			Color c = Gizmos.color;

			// draw grid
			Gizmos.color = Grid3D_ColorOutline;
			Gizmos.DrawLine(pos, pos + new Vector3(width * tileSize, 0f, 0f));
			Gizmos.DrawLine(pos, pos + new Vector3(0f, 0f, length * tileSize));
			Gizmos.DrawLine(pos + new Vector3(width * tileSize, 0f, length * tileSize), pos + new Vector3(width * tileSize, 0f, 0f));
			Gizmos.DrawLine(pos + new Vector3(width * tileSize, 0f, length * tileSize), pos + new Vector3(0f, 0f, length * tileSize));

			Gizmos.color = Grid3D_Color;
			for (int x = 1; x < width; x++)
			{
				Gizmos.DrawLine(pos + new Vector3(x * tileSize, 0f, 0f), pos + new Vector3(x * tileSize, 0f, length * tileSize));
			}
			for (int y = 1; y < length; y++)
			{
				Gizmos.DrawLine(pos + new Vector3(0f, 0f, y * tileSize), pos + new Vector3(width * tileSize, 0f, y * tileSize));
			}

			// draw a little handle to show where map's 0x0x0 corner is
			Gizmos.color = Color.white;
			Vector3 pos0 = this.transform.position;
			pos0.x -= tileSize / 2f;
			pos0.z -= tileSize / 2f;
			Gizmos.DrawCube(pos0 - new Vector3(0.05f, 0f, 0.05f), new Vector3(0.2f, 0.05f, 0.2f));
			Gizmos.DrawLine(pos0, pos);

			Gizmos.color = c;
		}

		#endregion
		// ================================================================================================================
	}
}