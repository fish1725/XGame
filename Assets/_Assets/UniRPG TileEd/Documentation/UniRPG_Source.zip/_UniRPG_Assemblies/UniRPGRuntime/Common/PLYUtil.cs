// ====================================================================================================================
// PLY Common Classes
// by Leslie Young
// www.plyoung.com
// ====================================================================================================================

using UnityEngine;

namespace PLYCommon
{
	public class PLYUtil
	{

		public static Color RandomColor()
		{
			return new Color(Random.Range(0.1f, 1f), Random.Range(0.1f, 1f), Random.Range(0.1f, 1f));
		}

		/// <summary>
		/// Destroys an Object by using Object.DestroyImmediate() when called 
		/// from Editor class and not in Play mode, else Object.Destroy()
		/// </summary>
		public static void DestroyObject(UnityEngine.Object obj, float t = 0.0f)
		{
			if (Application.isEditor && !Application.isPlaying) UnityEngine.Object.DestroyImmediate(obj);
			else UnityEngine.Object.Destroy(obj, t);
		}

		/// <summary>remove all colliders for the objet and its children</summary>
		public static void DestroyColliders(GameObject obj)
		{
			if (obj.collider) PLYUtil.DestroyObject(obj.collider);
			if (obj.transform.childCount == 0) return;
			for (int i = 0; i < obj.transform.childCount; i++)
			{
				PLYUtil.DestroyColliders(obj.transform.GetChild(i).gameObject);
			}
		}

		// ================================================================================================================
	}
}